grammar compilador;

fragment LETRA : [A-Za-z] ;
fragment DIGITO : [0-9] ;

PA : '(' ;
PC : ')' ;
LLA : '{' ;
LLC : '}' ;
PYC : ';' ;
ASIG : '=' ;

NUMERO : DIGITO+ ;

INT : 'int' ;
DOUBLE : 'double' ;
VOID : 'void' ;
WHILE : 'while' ;
IF : 'if' ;
ELSE : 'else' ;
FOR : 'for' ;
COMA : ',' ;
SUMA : '+';
ASUMA : '++';
RESTA : '-';
ARESTA : '--';
MULT : '*' ;
DIV : '/' ;
MOD : '%' ;
MA : '>' ;
ME : '<' ;
MAI : '>=' ;
MEI : '<=' ;
AND : '&&' ;
OR : '||' ;
IGUALDAD : '==' ;
DESIGUALDAD : '!=' ;
RETURN : 'return' ;

ID : (LETRA | '_')(LETRA | DIGITO | '_')* ;

WS : [ \n\r\t] -> skip ;
OTRO : . ;

// s : ID     {print("ID ->" + $ID.text + "<--") }         s
//   | NUMERO {print("NUMERO ->" + $NUMERO.text + "<--") } s
//   | OTRO   {print("Otro ->" + $OTRO.text + "<--") }     s
//   | EOF
//   ;

// s : PA s PC s
//   |
//   ;

programa : instrucciones EOF ;

instrucciones : instruccion instrucciones
          |;

instruccion : auto
          | asignacion
          | declaracion
          | prototipoFunc
          | llamadaFuncInstruccion
          | declaracionFunc
          | iwhile
          | iif
          | ifor
          | ireturn
          | bloque
          ;

bloque : LLA instrucciones LLC ;


// i++ o ++i
autosuma: ID ASUMA
     | ASUMA ID;

// i-- o --i
autoresta: ID ARESTA
     | ARESTA ID;

auto: autosuma
     | autoresta;

iwhile : WHILE PA opal PC instruccion ;


//Entre asignacion y opal tuve que sacar un PYC, ya lo traen incluidos.
ifor : FOR PA tipo asignacionSimple PYC opal PYC auto PC instruccion
     | FOR PA tipo asignacionSimple PYC opal PYC asignacionSimple PC instruccion
     | FOR PA asignacion opal PYC auto PC instruccion
     | FOR PA asignacion opal PYC asignacionSimple PC instruccion
     ;

iif : IF PA opal PC instruccion ielse ;

//NO HACER DO WHILE NI SWITCH, TAMPOCO FOR EACH

ielse : ELSE instruccion
     |      
     ;

declaracion : tipo ID inic listavar PYC ; //Probar que en lugar de inicializar pueda por ejemplo int x = 0, y, z; Algo así con una asignacion entre medio. --> HECHO FUNCIONA

listavar : COMA ID inic listavar
          |
          ;

inic : ASIG opal 
| 
;

//FUNCIONES

ireturn : RETURN opal PYC;

// PROTOTIPADO
parametro : tipo ID;

prototipoFunc : tipo ID PA parametros PC PYC ;


parametros : parametro listapar 
     | ;

listapar : COMA parametro listapar
     | ;

// LLAMADA
argumento : opal ;

argumentos : argumento listaargumentos
     | ;

listaargumentos : COMA argumento listaargumentos
     | ;

llamadaFunc : ID PA argumentos PC ;

llamadaFuncInstruccion : llamadaFunc PYC ;

// DECLARACION

declaracionFunc : tipo ID PA parametros PC bloque ;

tipo : INT
     | DOUBLE
     | VOID
     ;

asignacion : ID ASIG opal PYC ;

asignacionSimple : ID ASIG opal ;

opal : expOR ;

expOR : expAND expORp ;

expORp : OR expAND expORp
          |
          ;

expAND : expIGUAL expANDp ;

expANDp : AND expIGUAL expANDp
          |
          ;

expIGUAL : expCOMP expIGUALp ;

expIGUALp : IGUALDAD expCOMP expIGUALp
          | DESIGUALDAD expCOMP expIGUALp
          |
          ;

expCOMP : expSUMA expCOMPp ;

expCOMPp : MA expSUMA expCOMPp
          | ME expSUMA expCOMPp
          | MAI expSUMA expCOMPp
          | MEI expSUMA expCOMPp
          |
          ;

expSUMA : term expSUMAp ;

expSUMAp : SUMA term expSUMAp
          | RESTA term expSUMAp
          |
          ;

term : factor termp ;

termp : MULT factor termp
          | DIV factor termp
          | MOD factor termp
          |
          ;

factor : NUMERO
          | ID
          | llamadaFunc
          | PA opal PC
          ;
