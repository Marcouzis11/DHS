# Generated from /home/marc/Documentos/GitHub/DHS/ProyectoDHS/DHS2025-main(3)/DHS2025-main/src/main/python/compilador.g4 by ANTLR 4.13.1
from antlr4 import *
if "." in __name__:
    from .compiladorParser import compiladorParser
else:
    from compiladorParser import compiladorParser

# This class defines a complete listener for a parse tree produced by compiladorParser.
class compiladorListener(ParseTreeListener):

    # Enter a parse tree produced by compiladorParser#programa.
    def enterPrograma(self, ctx:compiladorParser.ProgramaContext):
        pass

    # Exit a parse tree produced by compiladorParser#programa.
    def exitPrograma(self, ctx:compiladorParser.ProgramaContext):
        pass


    # Enter a parse tree produced by compiladorParser#instrucciones.
    def enterInstrucciones(self, ctx:compiladorParser.InstruccionesContext):
        pass

    # Exit a parse tree produced by compiladorParser#instrucciones.
    def exitInstrucciones(self, ctx:compiladorParser.InstruccionesContext):
        pass


    # Enter a parse tree produced by compiladorParser#instruccion.
    def enterInstruccion(self, ctx:compiladorParser.InstruccionContext):
        pass

    # Exit a parse tree produced by compiladorParser#instruccion.
    def exitInstruccion(self, ctx:compiladorParser.InstruccionContext):
        pass


    # Enter a parse tree produced by compiladorParser#bloque.
    def enterBloque(self, ctx:compiladorParser.BloqueContext):
        pass

    # Exit a parse tree produced by compiladorParser#bloque.
    def exitBloque(self, ctx:compiladorParser.BloqueContext):
        pass


    # Enter a parse tree produced by compiladorParser#autosuma.
    def enterAutosuma(self, ctx:compiladorParser.AutosumaContext):
        pass

    # Exit a parse tree produced by compiladorParser#autosuma.
    def exitAutosuma(self, ctx:compiladorParser.AutosumaContext):
        pass


    # Enter a parse tree produced by compiladorParser#autoresta.
    def enterAutoresta(self, ctx:compiladorParser.AutorestaContext):
        pass

    # Exit a parse tree produced by compiladorParser#autoresta.
    def exitAutoresta(self, ctx:compiladorParser.AutorestaContext):
        pass


    # Enter a parse tree produced by compiladorParser#auto.
    def enterAuto(self, ctx:compiladorParser.AutoContext):
        pass

    # Exit a parse tree produced by compiladorParser#auto.
    def exitAuto(self, ctx:compiladorParser.AutoContext):
        pass


    # Enter a parse tree produced by compiladorParser#iwhile.
    def enterIwhile(self, ctx:compiladorParser.IwhileContext):
        pass

    # Exit a parse tree produced by compiladorParser#iwhile.
    def exitIwhile(self, ctx:compiladorParser.IwhileContext):
        pass


    # Enter a parse tree produced by compiladorParser#ifor.
    def enterIfor(self, ctx:compiladorParser.IforContext):
        pass

    # Exit a parse tree produced by compiladorParser#ifor.
    def exitIfor(self, ctx:compiladorParser.IforContext):
        pass


    # Enter a parse tree produced by compiladorParser#iif.
    def enterIif(self, ctx:compiladorParser.IifContext):
        pass

    # Exit a parse tree produced by compiladorParser#iif.
    def exitIif(self, ctx:compiladorParser.IifContext):
        pass


    # Enter a parse tree produced by compiladorParser#ielse.
    def enterIelse(self, ctx:compiladorParser.IelseContext):
        pass

    # Exit a parse tree produced by compiladorParser#ielse.
    def exitIelse(self, ctx:compiladorParser.IelseContext):
        pass


    # Enter a parse tree produced by compiladorParser#declaracion.
    def enterDeclaracion(self, ctx:compiladorParser.DeclaracionContext):
        pass

    # Exit a parse tree produced by compiladorParser#declaracion.
    def exitDeclaracion(self, ctx:compiladorParser.DeclaracionContext):
        pass


    # Enter a parse tree produced by compiladorParser#listavar.
    def enterListavar(self, ctx:compiladorParser.ListavarContext):
        pass

    # Exit a parse tree produced by compiladorParser#listavar.
    def exitListavar(self, ctx:compiladorParser.ListavarContext):
        pass


    # Enter a parse tree produced by compiladorParser#inic.
    def enterInic(self, ctx:compiladorParser.InicContext):
        pass

    # Exit a parse tree produced by compiladorParser#inic.
    def exitInic(self, ctx:compiladorParser.InicContext):
        pass


    # Enter a parse tree produced by compiladorParser#ireturn.
    def enterIreturn(self, ctx:compiladorParser.IreturnContext):
        pass

    # Exit a parse tree produced by compiladorParser#ireturn.
    def exitIreturn(self, ctx:compiladorParser.IreturnContext):
        pass


    # Enter a parse tree produced by compiladorParser#parametro.
    def enterParametro(self, ctx:compiladorParser.ParametroContext):
        pass

    # Exit a parse tree produced by compiladorParser#parametro.
    def exitParametro(self, ctx:compiladorParser.ParametroContext):
        pass


    # Enter a parse tree produced by compiladorParser#prototipoFunc.
    def enterPrototipoFunc(self, ctx:compiladorParser.PrototipoFuncContext):
        pass

    # Exit a parse tree produced by compiladorParser#prototipoFunc.
    def exitPrototipoFunc(self, ctx:compiladorParser.PrototipoFuncContext):
        pass


    # Enter a parse tree produced by compiladorParser#parametros.
    def enterParametros(self, ctx:compiladorParser.ParametrosContext):
        pass

    # Exit a parse tree produced by compiladorParser#parametros.
    def exitParametros(self, ctx:compiladorParser.ParametrosContext):
        pass


    # Enter a parse tree produced by compiladorParser#listapar.
    def enterListapar(self, ctx:compiladorParser.ListaparContext):
        pass

    # Exit a parse tree produced by compiladorParser#listapar.
    def exitListapar(self, ctx:compiladorParser.ListaparContext):
        pass


    # Enter a parse tree produced by compiladorParser#argumento.
    def enterArgumento(self, ctx:compiladorParser.ArgumentoContext):
        pass

    # Exit a parse tree produced by compiladorParser#argumento.
    def exitArgumento(self, ctx:compiladorParser.ArgumentoContext):
        pass


    # Enter a parse tree produced by compiladorParser#argumentos.
    def enterArgumentos(self, ctx:compiladorParser.ArgumentosContext):
        pass

    # Exit a parse tree produced by compiladorParser#argumentos.
    def exitArgumentos(self, ctx:compiladorParser.ArgumentosContext):
        pass


    # Enter a parse tree produced by compiladorParser#listaargumentos.
    def enterListaargumentos(self, ctx:compiladorParser.ListaargumentosContext):
        pass

    # Exit a parse tree produced by compiladorParser#listaargumentos.
    def exitListaargumentos(self, ctx:compiladorParser.ListaargumentosContext):
        pass


    # Enter a parse tree produced by compiladorParser#llamadaFunc.
    def enterLlamadaFunc(self, ctx:compiladorParser.LlamadaFuncContext):
        pass

    # Exit a parse tree produced by compiladorParser#llamadaFunc.
    def exitLlamadaFunc(self, ctx:compiladorParser.LlamadaFuncContext):
        pass


    # Enter a parse tree produced by compiladorParser#llamadaFuncInstruccion.
    def enterLlamadaFuncInstruccion(self, ctx:compiladorParser.LlamadaFuncInstruccionContext):
        pass

    # Exit a parse tree produced by compiladorParser#llamadaFuncInstruccion.
    def exitLlamadaFuncInstruccion(self, ctx:compiladorParser.LlamadaFuncInstruccionContext):
        pass


    # Enter a parse tree produced by compiladorParser#declaracionFunc.
    def enterDeclaracionFunc(self, ctx:compiladorParser.DeclaracionFuncContext):
        pass

    # Exit a parse tree produced by compiladorParser#declaracionFunc.
    def exitDeclaracionFunc(self, ctx:compiladorParser.DeclaracionFuncContext):
        pass


    # Enter a parse tree produced by compiladorParser#tipo.
    def enterTipo(self, ctx:compiladorParser.TipoContext):
        pass

    # Exit a parse tree produced by compiladorParser#tipo.
    def exitTipo(self, ctx:compiladorParser.TipoContext):
        pass


    # Enter a parse tree produced by compiladorParser#asignacion.
    def enterAsignacion(self, ctx:compiladorParser.AsignacionContext):
        pass

    # Exit a parse tree produced by compiladorParser#asignacion.
    def exitAsignacion(self, ctx:compiladorParser.AsignacionContext):
        pass


    # Enter a parse tree produced by compiladorParser#asignacionSimple.
    def enterAsignacionSimple(self, ctx:compiladorParser.AsignacionSimpleContext):
        pass

    # Exit a parse tree produced by compiladorParser#asignacionSimple.
    def exitAsignacionSimple(self, ctx:compiladorParser.AsignacionSimpleContext):
        pass


    # Enter a parse tree produced by compiladorParser#opal.
    def enterOpal(self, ctx:compiladorParser.OpalContext):
        pass

    # Exit a parse tree produced by compiladorParser#opal.
    def exitOpal(self, ctx:compiladorParser.OpalContext):
        pass


    # Enter a parse tree produced by compiladorParser#expOR.
    def enterExpOR(self, ctx:compiladorParser.ExpORContext):
        pass

    # Exit a parse tree produced by compiladorParser#expOR.
    def exitExpOR(self, ctx:compiladorParser.ExpORContext):
        pass


    # Enter a parse tree produced by compiladorParser#expORp.
    def enterExpORp(self, ctx:compiladorParser.ExpORpContext):
        pass

    # Exit a parse tree produced by compiladorParser#expORp.
    def exitExpORp(self, ctx:compiladorParser.ExpORpContext):
        pass


    # Enter a parse tree produced by compiladorParser#expAND.
    def enterExpAND(self, ctx:compiladorParser.ExpANDContext):
        pass

    # Exit a parse tree produced by compiladorParser#expAND.
    def exitExpAND(self, ctx:compiladorParser.ExpANDContext):
        pass


    # Enter a parse tree produced by compiladorParser#expANDp.
    def enterExpANDp(self, ctx:compiladorParser.ExpANDpContext):
        pass

    # Exit a parse tree produced by compiladorParser#expANDp.
    def exitExpANDp(self, ctx:compiladorParser.ExpANDpContext):
        pass


    # Enter a parse tree produced by compiladorParser#expIGUAL.
    def enterExpIGUAL(self, ctx:compiladorParser.ExpIGUALContext):
        pass

    # Exit a parse tree produced by compiladorParser#expIGUAL.
    def exitExpIGUAL(self, ctx:compiladorParser.ExpIGUALContext):
        pass


    # Enter a parse tree produced by compiladorParser#expIGUALp.
    def enterExpIGUALp(self, ctx:compiladorParser.ExpIGUALpContext):
        pass

    # Exit a parse tree produced by compiladorParser#expIGUALp.
    def exitExpIGUALp(self, ctx:compiladorParser.ExpIGUALpContext):
        pass


    # Enter a parse tree produced by compiladorParser#expCOMP.
    def enterExpCOMP(self, ctx:compiladorParser.ExpCOMPContext):
        pass

    # Exit a parse tree produced by compiladorParser#expCOMP.
    def exitExpCOMP(self, ctx:compiladorParser.ExpCOMPContext):
        pass


    # Enter a parse tree produced by compiladorParser#expCOMPp.
    def enterExpCOMPp(self, ctx:compiladorParser.ExpCOMPpContext):
        pass

    # Exit a parse tree produced by compiladorParser#expCOMPp.
    def exitExpCOMPp(self, ctx:compiladorParser.ExpCOMPpContext):
        pass


    # Enter a parse tree produced by compiladorParser#expSUMA.
    def enterExpSUMA(self, ctx:compiladorParser.ExpSUMAContext):
        pass

    # Exit a parse tree produced by compiladorParser#expSUMA.
    def exitExpSUMA(self, ctx:compiladorParser.ExpSUMAContext):
        pass


    # Enter a parse tree produced by compiladorParser#expSUMAp.
    def enterExpSUMAp(self, ctx:compiladorParser.ExpSUMApContext):
        pass

    # Exit a parse tree produced by compiladorParser#expSUMAp.
    def exitExpSUMAp(self, ctx:compiladorParser.ExpSUMApContext):
        pass


    # Enter a parse tree produced by compiladorParser#term.
    def enterTerm(self, ctx:compiladorParser.TermContext):
        pass

    # Exit a parse tree produced by compiladorParser#term.
    def exitTerm(self, ctx:compiladorParser.TermContext):
        pass


    # Enter a parse tree produced by compiladorParser#termp.
    def enterTermp(self, ctx:compiladorParser.TermpContext):
        pass

    # Exit a parse tree produced by compiladorParser#termp.
    def exitTermp(self, ctx:compiladorParser.TermpContext):
        pass


    # Enter a parse tree produced by compiladorParser#factor.
    def enterFactor(self, ctx:compiladorParser.FactorContext):
        pass

    # Exit a parse tree produced by compiladorParser#factor.
    def exitFactor(self, ctx:compiladorParser.FactorContext):
        pass



del compiladorParser