# Generated from /home/marc/Documentos/GitHub/DHS/ProyectoDHS/DHS2025-main(3)/DHS2025-main/src/main/python/compilador.g4 by ANTLR 4.13.1
from antlr4 import *
if "." in __name__:
    from .compiladorParser import compiladorParser
else:
    from compiladorParser import compiladorParser

# This class defines a complete generic visitor for a parse tree produced by compiladorParser.

class compiladorVisitor(ParseTreeVisitor):

    # Visit a parse tree produced by compiladorParser#programa.
    def visitPrograma(self, ctx:compiladorParser.ProgramaContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by compiladorParser#instrucciones.
    def visitInstrucciones(self, ctx:compiladorParser.InstruccionesContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by compiladorParser#instruccion.
    def visitInstruccion(self, ctx:compiladorParser.InstruccionContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by compiladorParser#bloque.
    def visitBloque(self, ctx:compiladorParser.BloqueContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by compiladorParser#autosuma.
    def visitAutosuma(self, ctx:compiladorParser.AutosumaContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by compiladorParser#autoresta.
    def visitAutoresta(self, ctx:compiladorParser.AutorestaContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by compiladorParser#auto.
    def visitAuto(self, ctx:compiladorParser.AutoContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by compiladorParser#iwhile.
    def visitIwhile(self, ctx:compiladorParser.IwhileContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by compiladorParser#ifor.
    def visitIfor(self, ctx:compiladorParser.IforContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by compiladorParser#iif.
    def visitIif(self, ctx:compiladorParser.IifContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by compiladorParser#ielse.
    def visitIelse(self, ctx:compiladorParser.IelseContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by compiladorParser#declaracion.
    def visitDeclaracion(self, ctx:compiladorParser.DeclaracionContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by compiladorParser#listavar.
    def visitListavar(self, ctx:compiladorParser.ListavarContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by compiladorParser#inic.
    def visitInic(self, ctx:compiladorParser.InicContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by compiladorParser#ireturn.
    def visitIreturn(self, ctx:compiladorParser.IreturnContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by compiladorParser#parametro.
    def visitParametro(self, ctx:compiladorParser.ParametroContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by compiladorParser#prototipoFunc.
    def visitPrototipoFunc(self, ctx:compiladorParser.PrototipoFuncContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by compiladorParser#parametros.
    def visitParametros(self, ctx:compiladorParser.ParametrosContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by compiladorParser#listapar.
    def visitListapar(self, ctx:compiladorParser.ListaparContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by compiladorParser#argumento.
    def visitArgumento(self, ctx:compiladorParser.ArgumentoContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by compiladorParser#argumentos.
    def visitArgumentos(self, ctx:compiladorParser.ArgumentosContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by compiladorParser#listaargumentos.
    def visitListaargumentos(self, ctx:compiladorParser.ListaargumentosContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by compiladorParser#llamadaFunc.
    def visitLlamadaFunc(self, ctx:compiladorParser.LlamadaFuncContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by compiladorParser#llamadaFuncInstruccion.
    def visitLlamadaFuncInstruccion(self, ctx:compiladorParser.LlamadaFuncInstruccionContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by compiladorParser#declaracionFunc.
    def visitDeclaracionFunc(self, ctx:compiladorParser.DeclaracionFuncContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by compiladorParser#tipo.
    def visitTipo(self, ctx:compiladorParser.TipoContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by compiladorParser#asignacion.
    def visitAsignacion(self, ctx:compiladorParser.AsignacionContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by compiladorParser#asignacionSimple.
    def visitAsignacionSimple(self, ctx:compiladorParser.AsignacionSimpleContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by compiladorParser#opal.
    def visitOpal(self, ctx:compiladorParser.OpalContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by compiladorParser#expOR.
    def visitExpOR(self, ctx:compiladorParser.ExpORContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by compiladorParser#expORp.
    def visitExpORp(self, ctx:compiladorParser.ExpORpContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by compiladorParser#expAND.
    def visitExpAND(self, ctx:compiladorParser.ExpANDContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by compiladorParser#expANDp.
    def visitExpANDp(self, ctx:compiladorParser.ExpANDpContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by compiladorParser#expIGUAL.
    def visitExpIGUAL(self, ctx:compiladorParser.ExpIGUALContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by compiladorParser#expIGUALp.
    def visitExpIGUALp(self, ctx:compiladorParser.ExpIGUALpContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by compiladorParser#expCOMP.
    def visitExpCOMP(self, ctx:compiladorParser.ExpCOMPContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by compiladorParser#expCOMPp.
    def visitExpCOMPp(self, ctx:compiladorParser.ExpCOMPpContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by compiladorParser#expSUMA.
    def visitExpSUMA(self, ctx:compiladorParser.ExpSUMAContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by compiladorParser#expSUMAp.
    def visitExpSUMAp(self, ctx:compiladorParser.ExpSUMApContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by compiladorParser#term.
    def visitTerm(self, ctx:compiladorParser.TermContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by compiladorParser#termp.
    def visitTermp(self, ctx:compiladorParser.TermpContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by compiladorParser#factor.
    def visitFactor(self, ctx:compiladorParser.FactorContext):
        return self.visitChildren(ctx)



del compiladorParser