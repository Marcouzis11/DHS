grammar compilador;

fragment LETRA : [A-Za-z] ;
fragment DIGITO : [0-9] ;

PA : '(' ;
PC : ')' ;
LLA : '{' ;
LLC : '}' ;
PYC : ';' ;
ASIG : '=' ;

NUMERO : DIGITO+ ;

INT : 'int' ;
DOUBLE : 'double' ;
WHILE : 'while' ;
IF : 'if' ;
ELSE : 'else' ;
FOR : 'for' ;
COMA : ',' ;
SUMA : '+';
ASUMA : '++';
RESTA : '-';
ARESTA : '--';
MULT : '*' ;
DIV : '/' ;
MOD : '%' ;
MA : '>' ;
ME : '<' ;
MAI : '>=' ;
MEI : '<=' ;
AND : '&&' ;
OR : '||' ;
IGUALDAD : '==' ;
DESIGUALDAD : '!=' ;


ID : (LETRA | '_')(LETRA | DIGITO | '_')* ;

WS : [ \n\r\t] -> skip ;
OTRO : . ;

// s : ID     {print("ID ->" + $ID.text + "<--") }         s
//   | NUMERO {print("NUMERO ->" + $NUMERO.text + "<--") } s
//   | OTRO   {print("Otro ->" + $OTRO.text + "<--") }     s
//   | EOF
//   ;

// s : PA s PC s
//   |
//   ;

programa : instrucciones EOF ;

instrucciones : instruccion instrucciones
          |;

instruccion : asignacion
          | declaracion
          | prototipoFunc
          | llamadaFuncInstruccion
          | declaracionFunc
          | iwhile
          | iif
          | ifor
          | autosuma
          | autoresta
          | bloque
          ;

bloque : LLA instrucciones LLC ;


// i++ o ++i
autosuma: ID ASUMA
     | ASUMA ID;

// i-- o --i
autoresta: ID ARESTA
     | ARESTA ID;

iwhile : WHILE PA opal PC instruccion ;


//Entre asignacion y opal tuve que sacar un PYC, ya lo traen incluidos.
ifor : FOR PA asignacion opal PYC instruccion PC instruccion 
     | FOR PA tipo asignacion opal PYC instruccion PC instruccion;

iif : IF PA opal PC instruccion ielse ;

//NO HACER DO WHILE NI SWITCH, TAMPOCO FOR EACH

ielse : ELSE instruccion
     |      
     ;

declaracion : tipo ID inic listavar PYC ; //Probar que en lugar de inicializar pueda por ejemplo int x = 0, y, z; Algo así con una asignacion entre medio. --> HECHO FUNCIONA

listavar : COMA ID inic listavar
          |
          ;

inic : ASIG opal 
| 
;

//FUNCIONES

// PROTOTIPADO
parametro : tipo ID;

prototipoFunc : tipo ID PA parametros PC PYC ;


parametros : parametro listapar 
     | ;

listapar : COMA parametro listapar
     | ;

// LLAMADA
argumento : ID
     | NUMERO
     | exp;

argumentos : argumento listaargumentos
     | ;

listaargumentos : COMA argumento listaargumentos
     | ;

llamadaFunc : ID PA argumentos PC ;

llamadaFuncInstruccion : llamadaFunc PYC ;

// DECLARACION

declaracionFunc : tipo ID PA parametros PC bloque ;

tipo : INT
     | DOUBLE
     ;

asignacion : ID ASIG opal PYC ;

opal : NUMERO
     | ID
     | exp
     | llamadaFunc
     ;

exp : term e logica igualdades;

e : SUMA term e
     | RESTA term e
     |;

term : factor t ;

t: MULT factor t
| DIV factor t
| MOD factor t
| ;

factor : NUMERO
     | ID
     | PA exp PC
     ;

logica : MA exp logica
     | ME exp logica
     | MAI exp logica
     | MEI exp logica
     | AND exp logica
     | OR exp logica
     | /* vacío */ ;

igualdades : IGUALDAD exp igualdades
     | DESIGUALDAD exp igualdades
     | ;
