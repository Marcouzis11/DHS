// Generated from /home/marc/Documentos/GitHub/DHS/ProyectoDHS/DHS2025-main(3)/DHS2025-main/src/main/python/compiladorViejo.g4 by ANTLR 4.13.1
import org.antlr.v4.runtime.Lexer;
import org.antlr.v4.runtime.CharStream;
import org.antlr.v4.runtime.Token;
import org.antlr.v4.runtime.TokenStream;
import org.antlr.v4.runtime.*;
import org.antlr.v4.runtime.atn.*;
import org.antlr.v4.runtime.dfa.DFA;
import org.antlr.v4.runtime.misc.*;

@SuppressWarnings({"all", "warnings", "unchecked", "unused", "cast", "CheckReturnValue", "this-escape"})
public class compiladorLexer extends Lexer {
	static { RuntimeMetaData.checkVersion("4.13.1", RuntimeMetaData.VERSION); }

	protected static final DFA[] _decisionToDFA;
	protected static final PredictionContextCache _sharedContextCache =
		new PredictionContextCache();
	public static final int
		PA=1, PC=2, LLA=3, LLC=4, PYC=5, ASIG=6, NUMERO=7, INT=8, DOUBLE=9, WHILE=10, 
		IF=11, ELSE=12, FOR=13, COMA=14, SUMA=15, RESTA=16, MULT=17, DIV=18, MOD=19, 
		MA=20, ME=21, MAI=22, MEI=23, AND=24, OR=25, IGUALDAD=26, DESIGUALDAD=27, 
		ID=28, WS=29, OTRO=30;
	public static String[] channelNames = {
		"DEFAULT_TOKEN_CHANNEL", "HIDDEN"
	};

	public static String[] modeNames = {
		"DEFAULT_MODE"
	};

	private static String[] makeRuleNames() {
		return new String[] {
			"LETRA", "DIGITO", "PA", "PC", "LLA", "LLC", "PYC", "ASIG", "NUMERO", 
			"INT", "DOUBLE", "WHILE", "IF", "ELSE", "FOR", "COMA", "SUMA", "RESTA", 
			"MULT", "DIV", "MOD", "MA", "ME", "MAI", "MEI", "AND", "OR", "IGUALDAD", 
			"DESIGUALDAD", "ID", "WS", "OTRO"
		};
	}
	public static final String[] ruleNames = makeRuleNames();

	private static String[] makeLiteralNames() {
		return new String[] {
			null, "'('", "')'", "'{'", "'}'", "';'", "'='", null, "'int'", "'double'", 
			"'while'", "'if'", "'else'", "'for'", "','", "'+'", "'-'", "'*'", "'/'", 
			"'%'", "'>'", "'<'", "'>='", "'<='", "'&&'", "'||'", "'=='", "'!='"
		};
	}
	private static final String[] _LITERAL_NAMES = makeLiteralNames();
	private static String[] makeSymbolicNames() {
		return new String[] {
			null, "PA", "PC", "LLA", "LLC", "PYC", "ASIG", "NUMERO", "INT", "DOUBLE", 
			"WHILE", "IF", "ELSE", "FOR", "COMA", "SUMA", "RESTA", "MULT", "DIV", 
			"MOD", "MA", "ME", "MAI", "MEI", "AND", "OR", "IGUALDAD", "DESIGUALDAD", 
			"ID", "WS", "OTRO"
		};
	}
	private static final String[] _SYMBOLIC_NAMES = makeSymbolicNames();
	public static final Vocabulary VOCABULARY = new VocabularyImpl(_LITERAL_NAMES, _SYMBOLIC_NAMES);

	/**
	 * @deprecated Use {@link #VOCABULARY} instead.
	 */
	@Deprecated
	public static final String[] tokenNames;
	static {
		tokenNames = new String[_SYMBOLIC_NAMES.length];
		for (int i = 0; i < tokenNames.length; i++) {
			tokenNames[i] = VOCABULARY.getLiteralName(i);
			if (tokenNames[i] == null) {
				tokenNames[i] = VOCABULARY.getSymbolicName(i);
			}

			if (tokenNames[i] == null) {
				tokenNames[i] = "<INVALID>";
			}
		}
	}

	@Override
	@Deprecated
	public String[] getTokenNames() {
		return tokenNames;
	}

	@Override

	public Vocabulary getVocabulary() {
		return VOCABULARY;
	}


	public compiladorLexer(CharStream input) {
		super(input);
		_interp = new LexerATNSimulator(this,_ATN,_decisionToDFA,_sharedContextCache);
	}

	@Override
	public String getGrammarFileName() { return "compiladorViejo.g4"; }

	@Override
	public String[] getRuleNames() { return ruleNames; }

	@Override
	public String getSerializedATN() { return _serializedATN; }

	@Override
	public String[] getChannelNames() { return channelNames; }

	@Override
	public String[] getModeNames() { return modeNames; }

	@Override
	public ATN getATN() { return _ATN; }

	public static final String _serializedATN =
		"\u0004\u0000\u001e\u00a7\u0006\uffff\uffff\u0002\u0000\u0007\u0000\u0002"+
		"\u0001\u0007\u0001\u0002\u0002\u0007\u0002\u0002\u0003\u0007\u0003\u0002"+
		"\u0004\u0007\u0004\u0002\u0005\u0007\u0005\u0002\u0006\u0007\u0006\u0002"+
		"\u0007\u0007\u0007\u0002\b\u0007\b\u0002\t\u0007\t\u0002\n\u0007\n\u0002"+
		"\u000b\u0007\u000b\u0002\f\u0007\f\u0002\r\u0007\r\u0002\u000e\u0007\u000e"+
		"\u0002\u000f\u0007\u000f\u0002\u0010\u0007\u0010\u0002\u0011\u0007\u0011"+
		"\u0002\u0012\u0007\u0012\u0002\u0013\u0007\u0013\u0002\u0014\u0007\u0014"+
		"\u0002\u0015\u0007\u0015\u0002\u0016\u0007\u0016\u0002\u0017\u0007\u0017"+
		"\u0002\u0018\u0007\u0018\u0002\u0019\u0007\u0019\u0002\u001a\u0007\u001a"+
		"\u0002\u001b\u0007\u001b\u0002\u001c\u0007\u001c\u0002\u001d\u0007\u001d"+
		"\u0002\u001e\u0007\u001e\u0002\u001f\u0007\u001f\u0001\u0000\u0001\u0000"+
		"\u0001\u0001\u0001\u0001\u0001\u0002\u0001\u0002\u0001\u0003\u0001\u0003"+
		"\u0001\u0004\u0001\u0004\u0001\u0005\u0001\u0005\u0001\u0006\u0001\u0006"+
		"\u0001\u0007\u0001\u0007\u0001\b\u0004\bS\b\b\u000b\b\f\bT\u0001\t\u0001"+
		"\t\u0001\t\u0001\t\u0001\n\u0001\n\u0001\n\u0001\n\u0001\n\u0001\n\u0001"+
		"\n\u0001\u000b\u0001\u000b\u0001\u000b\u0001\u000b\u0001\u000b\u0001\u000b"+
		"\u0001\f\u0001\f\u0001\f\u0001\r\u0001\r\u0001\r\u0001\r\u0001\r\u0001"+
		"\u000e\u0001\u000e\u0001\u000e\u0001\u000e\u0001\u000f\u0001\u000f\u0001"+
		"\u0010\u0001\u0010\u0001\u0011\u0001\u0011\u0001\u0012\u0001\u0012\u0001"+
		"\u0013\u0001\u0013\u0001\u0014\u0001\u0014\u0001\u0015\u0001\u0015\u0001"+
		"\u0016\u0001\u0016\u0001\u0017\u0001\u0017\u0001\u0017\u0001\u0018\u0001"+
		"\u0018\u0001\u0018\u0001\u0019\u0001\u0019\u0001\u0019\u0001\u001a\u0001"+
		"\u001a\u0001\u001a\u0001\u001b\u0001\u001b\u0001\u001b\u0001\u001c\u0001"+
		"\u001c\u0001\u001c\u0001\u001d\u0001\u001d\u0003\u001d\u0098\b\u001d\u0001"+
		"\u001d\u0001\u001d\u0001\u001d\u0005\u001d\u009d\b\u001d\n\u001d\f\u001d"+
		"\u00a0\t\u001d\u0001\u001e\u0001\u001e\u0001\u001e\u0001\u001e\u0001\u001f"+
		"\u0001\u001f\u0000\u0000 \u0001\u0000\u0003\u0000\u0005\u0001\u0007\u0002"+
		"\t\u0003\u000b\u0004\r\u0005\u000f\u0006\u0011\u0007\u0013\b\u0015\t\u0017"+
		"\n\u0019\u000b\u001b\f\u001d\r\u001f\u000e!\u000f#\u0010%\u0011\'\u0012"+
		")\u0013+\u0014-\u0015/\u00161\u00173\u00185\u00197\u001a9\u001b;\u001c"+
		"=\u001d?\u001e\u0001\u0000\u0003\u0002\u0000AZaz\u0001\u000009\u0003\u0000"+
		"\t\n\r\r  \u00a9\u0000\u0005\u0001\u0000\u0000\u0000\u0000\u0007\u0001"+
		"\u0000\u0000\u0000\u0000\t\u0001\u0000\u0000\u0000\u0000\u000b\u0001\u0000"+
		"\u0000\u0000\u0000\r\u0001\u0000\u0000\u0000\u0000\u000f\u0001\u0000\u0000"+
		"\u0000\u0000\u0011\u0001\u0000\u0000\u0000\u0000\u0013\u0001\u0000\u0000"+
		"\u0000\u0000\u0015\u0001\u0000\u0000\u0000\u0000\u0017\u0001\u0000\u0000"+
		"\u0000\u0000\u0019\u0001\u0000\u0000\u0000\u0000\u001b\u0001\u0000\u0000"+
		"\u0000\u0000\u001d\u0001\u0000\u0000\u0000\u0000\u001f\u0001\u0000\u0000"+
		"\u0000\u0000!\u0001\u0000\u0000\u0000\u0000#\u0001\u0000\u0000\u0000\u0000"+
		"%\u0001\u0000\u0000\u0000\u0000\'\u0001\u0000\u0000\u0000\u0000)\u0001"+
		"\u0000\u0000\u0000\u0000+\u0001\u0000\u0000\u0000\u0000-\u0001\u0000\u0000"+
		"\u0000\u0000/\u0001\u0000\u0000\u0000\u00001\u0001\u0000\u0000\u0000\u0000"+
		"3\u0001\u0000\u0000\u0000\u00005\u0001\u0000\u0000\u0000\u00007\u0001"+
		"\u0000\u0000\u0000\u00009\u0001\u0000\u0000\u0000\u0000;\u0001\u0000\u0000"+
		"\u0000\u0000=\u0001\u0000\u0000\u0000\u0000?\u0001\u0000\u0000\u0000\u0001"+
		"A\u0001\u0000\u0000\u0000\u0003C\u0001\u0000\u0000\u0000\u0005E\u0001"+
		"\u0000\u0000\u0000\u0007G\u0001\u0000\u0000\u0000\tI\u0001\u0000\u0000"+
		"\u0000\u000bK\u0001\u0000\u0000\u0000\rM\u0001\u0000\u0000\u0000\u000f"+
		"O\u0001\u0000\u0000\u0000\u0011R\u0001\u0000\u0000\u0000\u0013V\u0001"+
		"\u0000\u0000\u0000\u0015Z\u0001\u0000\u0000\u0000\u0017a\u0001\u0000\u0000"+
		"\u0000\u0019g\u0001\u0000\u0000\u0000\u001bj\u0001\u0000\u0000\u0000\u001d"+
		"o\u0001\u0000\u0000\u0000\u001fs\u0001\u0000\u0000\u0000!u\u0001\u0000"+
		"\u0000\u0000#w\u0001\u0000\u0000\u0000%y\u0001\u0000\u0000\u0000\'{\u0001"+
		"\u0000\u0000\u0000)}\u0001\u0000\u0000\u0000+\u007f\u0001\u0000\u0000"+
		"\u0000-\u0081\u0001\u0000\u0000\u0000/\u0083\u0001\u0000\u0000\u00001"+
		"\u0086\u0001\u0000\u0000\u00003\u0089\u0001\u0000\u0000\u00005\u008c\u0001"+
		"\u0000\u0000\u00007\u008f\u0001\u0000\u0000\u00009\u0092\u0001\u0000\u0000"+
		"\u0000;\u0097\u0001\u0000\u0000\u0000=\u00a1\u0001\u0000\u0000\u0000?"+
		"\u00a5\u0001\u0000\u0000\u0000AB\u0007\u0000\u0000\u0000B\u0002\u0001"+
		"\u0000\u0000\u0000CD\u0007\u0001\u0000\u0000D\u0004\u0001\u0000\u0000"+
		"\u0000EF\u0005(\u0000\u0000F\u0006\u0001\u0000\u0000\u0000GH\u0005)\u0000"+
		"\u0000H\b\u0001\u0000\u0000\u0000IJ\u0005{\u0000\u0000J\n\u0001\u0000"+
		"\u0000\u0000KL\u0005}\u0000\u0000L\f\u0001\u0000\u0000\u0000MN\u0005;"+
		"\u0000\u0000N\u000e\u0001\u0000\u0000\u0000OP\u0005=\u0000\u0000P\u0010"+
		"\u0001\u0000\u0000\u0000QS\u0003\u0003\u0001\u0000RQ\u0001\u0000\u0000"+
		"\u0000ST\u0001\u0000\u0000\u0000TR\u0001\u0000\u0000\u0000TU\u0001\u0000"+
		"\u0000\u0000U\u0012\u0001\u0000\u0000\u0000VW\u0005i\u0000\u0000WX\u0005"+
		"n\u0000\u0000XY\u0005t\u0000\u0000Y\u0014\u0001\u0000\u0000\u0000Z[\u0005"+
		"d\u0000\u0000[\\\u0005o\u0000\u0000\\]\u0005u\u0000\u0000]^\u0005b\u0000"+
		"\u0000^_\u0005l\u0000\u0000_`\u0005e\u0000\u0000`\u0016\u0001\u0000\u0000"+
		"\u0000ab\u0005w\u0000\u0000bc\u0005h\u0000\u0000cd\u0005i\u0000\u0000"+
		"de\u0005l\u0000\u0000ef\u0005e\u0000\u0000f\u0018\u0001\u0000\u0000\u0000"+
		"gh\u0005i\u0000\u0000hi\u0005f\u0000\u0000i\u001a\u0001\u0000\u0000\u0000"+
		"jk\u0005e\u0000\u0000kl\u0005l\u0000\u0000lm\u0005s\u0000\u0000mn\u0005"+
		"e\u0000\u0000n\u001c\u0001\u0000\u0000\u0000op\u0005f\u0000\u0000pq\u0005"+
		"o\u0000\u0000qr\u0005r\u0000\u0000r\u001e\u0001\u0000\u0000\u0000st\u0005"+
		",\u0000\u0000t \u0001\u0000\u0000\u0000uv\u0005+\u0000\u0000v\"\u0001"+
		"\u0000\u0000\u0000wx\u0005-\u0000\u0000x$\u0001\u0000\u0000\u0000yz\u0005"+
		"*\u0000\u0000z&\u0001\u0000\u0000\u0000{|\u0005/\u0000\u0000|(\u0001\u0000"+
		"\u0000\u0000}~\u0005%\u0000\u0000~*\u0001\u0000\u0000\u0000\u007f\u0080"+
		"\u0005>\u0000\u0000\u0080,\u0001\u0000\u0000\u0000\u0081\u0082\u0005<"+
		"\u0000\u0000\u0082.\u0001\u0000\u0000\u0000\u0083\u0084\u0005>\u0000\u0000"+
		"\u0084\u0085\u0005=\u0000\u0000\u00850\u0001\u0000\u0000\u0000\u0086\u0087"+
		"\u0005<\u0000\u0000\u0087\u0088\u0005=\u0000\u0000\u00882\u0001\u0000"+
		"\u0000\u0000\u0089\u008a\u0005&\u0000\u0000\u008a\u008b\u0005&\u0000\u0000"+
		"\u008b4\u0001\u0000\u0000\u0000\u008c\u008d\u0005|\u0000\u0000\u008d\u008e"+
		"\u0005|\u0000\u0000\u008e6\u0001\u0000\u0000\u0000\u008f\u0090\u0005="+
		"\u0000\u0000\u0090\u0091\u0005=\u0000\u0000\u00918\u0001\u0000\u0000\u0000"+
		"\u0092\u0093\u0005!\u0000\u0000\u0093\u0094\u0005=\u0000\u0000\u0094:"+
		"\u0001\u0000\u0000\u0000\u0095\u0098\u0003\u0001\u0000\u0000\u0096\u0098"+
		"\u0005_\u0000\u0000\u0097\u0095\u0001\u0000\u0000\u0000\u0097\u0096\u0001"+
		"\u0000\u0000\u0000\u0098\u009e\u0001\u0000\u0000\u0000\u0099\u009d\u0003"+
		"\u0001\u0000\u0000\u009a\u009d\u0003\u0003\u0001\u0000\u009b\u009d\u0005"+
		"_\u0000\u0000\u009c\u0099\u0001\u0000\u0000\u0000\u009c\u009a\u0001\u0000"+
		"\u0000\u0000\u009c\u009b\u0001\u0000\u0000\u0000\u009d\u00a0\u0001\u0000"+
		"\u0000\u0000\u009e\u009c\u0001\u0000\u0000\u0000\u009e\u009f\u0001\u0000"+
		"\u0000\u0000\u009f<\u0001\u0000\u0000\u0000\u00a0\u009e\u0001\u0000\u0000"+
		"\u0000\u00a1\u00a2\u0007\u0002\u0000\u0000\u00a2\u00a3\u0001\u0000\u0000"+
		"\u0000\u00a3\u00a4\u0006\u001e\u0000\u0000\u00a4>\u0001\u0000\u0000\u0000"+
		"\u00a5\u00a6\t\u0000\u0000\u0000\u00a6@\u0001\u0000\u0000\u0000\u0005"+
		"\u0000T\u0097\u009c\u009e\u0001\u0006\u0000\u0000";
	public static final ATN _ATN =
		new ATNDeserializer().deserialize(_serializedATN.toCharArray());
	static {
		_decisionToDFA = new DFA[_ATN.getNumberOfDecisions()];
		for (int i = 0; i < _ATN.getNumberOfDecisions(); i++) {
			_decisionToDFA[i] = new DFA(_ATN.getDecisionState(i), i);
		}
	}
}