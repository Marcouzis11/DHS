# Generated from /home/marc/Documentos/GitHub/DHS/ProyectoDHS/DHS2025-main(3)/DHS2025-main/src/main/python/compilador.g4 by ANTLR 4.13.1
# encoding: utf-8
from antlr4 import *
from io import StringIO
import sys
if sys.version_info[1] > 5:
	from typing import TextIO
else:
	from typing.io import TextIO

def serializedATN():
    return [
        4,1,34,373,2,0,7,0,2,1,7,1,2,2,7,2,2,3,7,3,2,4,7,4,2,5,7,5,2,6,7,
        6,2,7,7,7,2,8,7,8,2,9,7,9,2,10,7,10,2,11,7,11,2,12,7,12,2,13,7,13,
        2,14,7,14,2,15,7,15,2,16,7,16,2,17,7,17,2,18,7,18,2,19,7,19,2,20,
        7,20,2,21,7,21,2,22,7,22,2,23,7,23,2,24,7,24,2,25,7,25,2,26,7,26,
        2,27,7,27,2,28,7,28,2,29,7,29,2,30,7,30,2,31,7,31,2,32,7,32,2,33,
        7,33,2,34,7,34,2,35,7,35,2,36,7,36,2,37,7,37,2,38,7,38,2,39,7,39,
        2,40,7,40,2,41,7,41,1,0,1,0,1,0,1,1,1,1,1,1,1,1,3,1,92,8,1,1,2,1,
        2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,3,2,105,8,2,1,3,1,3,1,3,1,
        3,1,4,1,4,1,4,1,4,3,4,115,8,4,1,5,1,5,1,5,1,5,3,5,121,8,5,1,6,1,
        6,3,6,125,8,6,1,7,1,7,1,7,1,7,1,7,1,7,1,8,1,8,1,8,1,8,1,8,1,8,1,
        8,1,8,1,8,1,8,1,8,1,8,1,8,1,8,1,8,1,8,1,8,1,8,1,8,1,8,1,8,1,8,1,
        8,1,8,1,8,1,8,1,8,1,8,1,8,1,8,1,8,1,8,1,8,1,8,1,8,1,8,1,8,1,8,1,
        8,1,8,3,8,173,8,8,1,9,1,9,1,9,1,9,1,9,1,9,1,9,1,10,1,10,1,10,3,10,
        185,8,10,1,11,1,11,1,11,1,11,1,11,1,11,1,12,1,12,1,12,1,12,1,12,
        1,12,3,12,199,8,12,1,13,1,13,1,13,3,13,204,8,13,1,14,1,14,1,14,1,
        14,1,15,1,15,1,15,1,16,1,16,1,16,1,16,1,16,1,16,1,16,1,17,1,17,1,
        17,1,17,3,17,224,8,17,1,18,1,18,1,18,1,18,1,18,3,18,231,8,18,1,19,
        1,19,1,20,1,20,1,20,1,20,3,20,239,8,20,1,21,1,21,1,21,1,21,1,21,
        3,21,246,8,21,1,22,1,22,1,22,1,22,1,22,1,23,1,23,1,23,1,24,1,24,
        1,24,1,24,1,24,1,24,1,24,1,25,1,25,1,26,1,26,1,26,1,26,1,26,1,27,
        1,27,1,27,1,27,1,28,1,28,1,29,1,29,1,29,1,30,1,30,1,30,1,30,1,30,
        3,30,284,8,30,1,31,1,31,1,31,1,32,1,32,1,32,1,32,1,32,3,32,294,8,
        32,1,33,1,33,1,33,1,34,1,34,1,34,1,34,1,34,1,34,1,34,1,34,1,34,3,
        34,308,8,34,1,35,1,35,1,35,1,36,1,36,1,36,1,36,1,36,1,36,1,36,1,
        36,1,36,1,36,1,36,1,36,1,36,1,36,1,36,1,36,1,36,3,36,330,8,36,1,
        37,1,37,1,37,1,38,1,38,1,38,1,38,1,38,1,38,1,38,1,38,1,38,3,38,344,
        8,38,1,39,1,39,1,39,1,40,1,40,1,40,1,40,1,40,1,40,1,40,1,40,1,40,
        1,40,1,40,1,40,1,40,3,40,362,8,40,1,41,1,41,1,41,1,41,1,41,1,41,
        1,41,3,41,371,8,41,1,41,0,0,42,0,2,4,6,8,10,12,14,16,18,20,22,24,
        26,28,30,32,34,36,38,40,42,44,46,48,50,52,54,56,58,60,62,64,66,68,
        70,72,74,76,78,80,82,0,1,1,0,8,10,370,0,84,1,0,0,0,2,91,1,0,0,0,
        4,104,1,0,0,0,6,106,1,0,0,0,8,114,1,0,0,0,10,120,1,0,0,0,12,124,
        1,0,0,0,14,126,1,0,0,0,16,172,1,0,0,0,18,174,1,0,0,0,20,184,1,0,
        0,0,22,186,1,0,0,0,24,198,1,0,0,0,26,203,1,0,0,0,28,205,1,0,0,0,
        30,209,1,0,0,0,32,212,1,0,0,0,34,223,1,0,0,0,36,230,1,0,0,0,38,232,
        1,0,0,0,40,238,1,0,0,0,42,245,1,0,0,0,44,247,1,0,0,0,46,252,1,0,
        0,0,48,255,1,0,0,0,50,262,1,0,0,0,52,264,1,0,0,0,54,269,1,0,0,0,
        56,273,1,0,0,0,58,275,1,0,0,0,60,283,1,0,0,0,62,285,1,0,0,0,64,293,
        1,0,0,0,66,295,1,0,0,0,68,307,1,0,0,0,70,309,1,0,0,0,72,329,1,0,
        0,0,74,331,1,0,0,0,76,343,1,0,0,0,78,345,1,0,0,0,80,361,1,0,0,0,
        82,370,1,0,0,0,84,85,3,2,1,0,85,86,5,0,0,1,86,1,1,0,0,0,87,88,3,
        4,2,0,88,89,3,2,1,0,89,92,1,0,0,0,90,92,1,0,0,0,91,87,1,0,0,0,91,
        90,1,0,0,0,92,3,1,0,0,0,93,105,3,12,6,0,94,105,3,52,26,0,95,105,
        3,22,11,0,96,105,3,32,16,0,97,105,3,46,23,0,98,105,3,48,24,0,99,
        105,3,14,7,0,100,105,3,18,9,0,101,105,3,16,8,0,102,105,3,28,14,0,
        103,105,3,6,3,0,104,93,1,0,0,0,104,94,1,0,0,0,104,95,1,0,0,0,104,
        96,1,0,0,0,104,97,1,0,0,0,104,98,1,0,0,0,104,99,1,0,0,0,104,100,
        1,0,0,0,104,101,1,0,0,0,104,102,1,0,0,0,104,103,1,0,0,0,105,5,1,
        0,0,0,106,107,5,3,0,0,107,108,3,2,1,0,108,109,5,4,0,0,109,7,1,0,
        0,0,110,111,5,32,0,0,111,115,5,17,0,0,112,113,5,17,0,0,113,115,5,
        32,0,0,114,110,1,0,0,0,114,112,1,0,0,0,115,9,1,0,0,0,116,117,5,32,
        0,0,117,121,5,19,0,0,118,119,5,19,0,0,119,121,5,32,0,0,120,116,1,
        0,0,0,120,118,1,0,0,0,121,11,1,0,0,0,122,125,3,8,4,0,123,125,3,10,
        5,0,124,122,1,0,0,0,124,123,1,0,0,0,125,13,1,0,0,0,126,127,5,11,
        0,0,127,128,5,1,0,0,128,129,3,56,28,0,129,130,5,2,0,0,130,131,3,
        4,2,0,131,15,1,0,0,0,132,133,5,14,0,0,133,134,5,1,0,0,134,135,3,
        50,25,0,135,136,3,54,27,0,136,137,5,5,0,0,137,138,3,56,28,0,138,
        139,5,5,0,0,139,140,3,12,6,0,140,141,5,2,0,0,141,142,3,4,2,0,142,
        173,1,0,0,0,143,144,5,14,0,0,144,145,5,1,0,0,145,146,3,50,25,0,146,
        147,3,54,27,0,147,148,5,5,0,0,148,149,3,56,28,0,149,150,5,5,0,0,
        150,151,3,54,27,0,151,152,5,2,0,0,152,153,3,4,2,0,153,173,1,0,0,
        0,154,155,5,14,0,0,155,156,5,1,0,0,156,157,3,52,26,0,157,158,3,56,
        28,0,158,159,5,5,0,0,159,160,3,12,6,0,160,161,5,2,0,0,161,162,3,
        4,2,0,162,173,1,0,0,0,163,164,5,14,0,0,164,165,5,1,0,0,165,166,3,
        52,26,0,166,167,3,56,28,0,167,168,5,5,0,0,168,169,3,54,27,0,169,
        170,5,2,0,0,170,171,3,4,2,0,171,173,1,0,0,0,172,132,1,0,0,0,172,
        143,1,0,0,0,172,154,1,0,0,0,172,163,1,0,0,0,173,17,1,0,0,0,174,175,
        5,12,0,0,175,176,5,1,0,0,176,177,3,56,28,0,177,178,5,2,0,0,178,179,
        3,4,2,0,179,180,3,20,10,0,180,19,1,0,0,0,181,182,5,13,0,0,182,185,
        3,4,2,0,183,185,1,0,0,0,184,181,1,0,0,0,184,183,1,0,0,0,185,21,1,
        0,0,0,186,187,3,50,25,0,187,188,5,32,0,0,188,189,3,26,13,0,189,190,
        3,24,12,0,190,191,5,5,0,0,191,23,1,0,0,0,192,193,5,15,0,0,193,194,
        5,32,0,0,194,195,3,26,13,0,195,196,3,24,12,0,196,199,1,0,0,0,197,
        199,1,0,0,0,198,192,1,0,0,0,198,197,1,0,0,0,199,25,1,0,0,0,200,201,
        5,6,0,0,201,204,3,56,28,0,202,204,1,0,0,0,203,200,1,0,0,0,203,202,
        1,0,0,0,204,27,1,0,0,0,205,206,5,31,0,0,206,207,3,56,28,0,207,208,
        5,5,0,0,208,29,1,0,0,0,209,210,3,50,25,0,210,211,5,32,0,0,211,31,
        1,0,0,0,212,213,3,50,25,0,213,214,5,32,0,0,214,215,5,1,0,0,215,216,
        3,34,17,0,216,217,5,2,0,0,217,218,5,5,0,0,218,33,1,0,0,0,219,220,
        3,30,15,0,220,221,3,36,18,0,221,224,1,0,0,0,222,224,1,0,0,0,223,
        219,1,0,0,0,223,222,1,0,0,0,224,35,1,0,0,0,225,226,5,15,0,0,226,
        227,3,30,15,0,227,228,3,36,18,0,228,231,1,0,0,0,229,231,1,0,0,0,
        230,225,1,0,0,0,230,229,1,0,0,0,231,37,1,0,0,0,232,233,3,56,28,0,
        233,39,1,0,0,0,234,235,3,38,19,0,235,236,3,42,21,0,236,239,1,0,0,
        0,237,239,1,0,0,0,238,234,1,0,0,0,238,237,1,0,0,0,239,41,1,0,0,0,
        240,241,5,15,0,0,241,242,3,38,19,0,242,243,3,42,21,0,243,246,1,0,
        0,0,244,246,1,0,0,0,245,240,1,0,0,0,245,244,1,0,0,0,246,43,1,0,0,
        0,247,248,5,32,0,0,248,249,5,1,0,0,249,250,3,40,20,0,250,251,5,2,
        0,0,251,45,1,0,0,0,252,253,3,44,22,0,253,254,5,5,0,0,254,47,1,0,
        0,0,255,256,3,50,25,0,256,257,5,32,0,0,257,258,5,1,0,0,258,259,3,
        34,17,0,259,260,5,2,0,0,260,261,3,6,3,0,261,49,1,0,0,0,262,263,7,
        0,0,0,263,51,1,0,0,0,264,265,5,32,0,0,265,266,5,6,0,0,266,267,3,
        56,28,0,267,268,5,5,0,0,268,53,1,0,0,0,269,270,5,32,0,0,270,271,
        5,6,0,0,271,272,3,56,28,0,272,55,1,0,0,0,273,274,3,58,29,0,274,57,
        1,0,0,0,275,276,3,62,31,0,276,277,3,60,30,0,277,59,1,0,0,0,278,279,
        5,28,0,0,279,280,3,62,31,0,280,281,3,60,30,0,281,284,1,0,0,0,282,
        284,1,0,0,0,283,278,1,0,0,0,283,282,1,0,0,0,284,61,1,0,0,0,285,286,
        3,66,33,0,286,287,3,64,32,0,287,63,1,0,0,0,288,289,5,27,0,0,289,
        290,3,66,33,0,290,291,3,64,32,0,291,294,1,0,0,0,292,294,1,0,0,0,
        293,288,1,0,0,0,293,292,1,0,0,0,294,65,1,0,0,0,295,296,3,70,35,0,
        296,297,3,68,34,0,297,67,1,0,0,0,298,299,5,29,0,0,299,300,3,70,35,
        0,300,301,3,68,34,0,301,308,1,0,0,0,302,303,5,30,0,0,303,304,3,70,
        35,0,304,305,3,68,34,0,305,308,1,0,0,0,306,308,1,0,0,0,307,298,1,
        0,0,0,307,302,1,0,0,0,307,306,1,0,0,0,308,69,1,0,0,0,309,310,3,74,
        37,0,310,311,3,72,36,0,311,71,1,0,0,0,312,313,5,23,0,0,313,314,3,
        74,37,0,314,315,3,72,36,0,315,330,1,0,0,0,316,317,5,24,0,0,317,318,
        3,74,37,0,318,319,3,72,36,0,319,330,1,0,0,0,320,321,5,25,0,0,321,
        322,3,74,37,0,322,323,3,72,36,0,323,330,1,0,0,0,324,325,5,26,0,0,
        325,326,3,74,37,0,326,327,3,72,36,0,327,330,1,0,0,0,328,330,1,0,
        0,0,329,312,1,0,0,0,329,316,1,0,0,0,329,320,1,0,0,0,329,324,1,0,
        0,0,329,328,1,0,0,0,330,73,1,0,0,0,331,332,3,78,39,0,332,333,3,76,
        38,0,333,75,1,0,0,0,334,335,5,16,0,0,335,336,3,78,39,0,336,337,3,
        76,38,0,337,344,1,0,0,0,338,339,5,18,0,0,339,340,3,78,39,0,340,341,
        3,76,38,0,341,344,1,0,0,0,342,344,1,0,0,0,343,334,1,0,0,0,343,338,
        1,0,0,0,343,342,1,0,0,0,344,77,1,0,0,0,345,346,3,82,41,0,346,347,
        3,80,40,0,347,79,1,0,0,0,348,349,5,20,0,0,349,350,3,82,41,0,350,
        351,3,80,40,0,351,362,1,0,0,0,352,353,5,21,0,0,353,354,3,82,41,0,
        354,355,3,80,40,0,355,362,1,0,0,0,356,357,5,22,0,0,357,358,3,82,
        41,0,358,359,3,80,40,0,359,362,1,0,0,0,360,362,1,0,0,0,361,348,1,
        0,0,0,361,352,1,0,0,0,361,356,1,0,0,0,361,360,1,0,0,0,362,81,1,0,
        0,0,363,371,5,7,0,0,364,371,5,32,0,0,365,371,3,44,22,0,366,367,5,
        1,0,0,367,368,3,56,28,0,368,369,5,2,0,0,369,371,1,0,0,0,370,363,
        1,0,0,0,370,364,1,0,0,0,370,365,1,0,0,0,370,366,1,0,0,0,371,83,1,
        0,0,0,20,91,104,114,120,124,172,184,198,203,223,230,238,245,283,
        293,307,329,343,361,370
    ]

class compiladorParser ( Parser ):

    grammarFileName = "compilador.g4"

    atn = ATNDeserializer().deserialize(serializedATN())

    decisionsToDFA = [ DFA(ds, i) for i, ds in enumerate(atn.decisionToState) ]

    sharedContextCache = PredictionContextCache()

    literalNames = [ "<INVALID>", "'('", "')'", "'{'", "'}'", "';'", "'='", 
                     "<INVALID>", "'int'", "'double'", "'void'", "'while'", 
                     "'if'", "'else'", "'for'", "','", "'+'", "'++'", "'-'", 
                     "'--'", "'*'", "'/'", "'%'", "'>'", "'<'", "'>='", 
                     "'<='", "'&&'", "'||'", "'=='", "'!='", "'return'" ]

    symbolicNames = [ "<INVALID>", "PA", "PC", "LLA", "LLC", "PYC", "ASIG", 
                      "NUMERO", "INT", "DOUBLE", "VOID", "WHILE", "IF", 
                      "ELSE", "FOR", "COMA", "SUMA", "ASUMA", "RESTA", "ARESTA", 
                      "MULT", "DIV", "MOD", "MA", "ME", "MAI", "MEI", "AND", 
                      "OR", "IGUALDAD", "DESIGUALDAD", "RETURN", "ID", "WS", 
                      "OTRO" ]

    RULE_programa = 0
    RULE_instrucciones = 1
    RULE_instruccion = 2
    RULE_bloque = 3
    RULE_autosuma = 4
    RULE_autoresta = 5
    RULE_auto = 6
    RULE_iwhile = 7
    RULE_ifor = 8
    RULE_iif = 9
    RULE_ielse = 10
    RULE_declaracion = 11
    RULE_listavar = 12
    RULE_inic = 13
    RULE_ireturn = 14
    RULE_parametro = 15
    RULE_prototipoFunc = 16
    RULE_parametros = 17
    RULE_listapar = 18
    RULE_argumento = 19
    RULE_argumentos = 20
    RULE_listaargumentos = 21
    RULE_llamadaFunc = 22
    RULE_llamadaFuncInstruccion = 23
    RULE_declaracionFunc = 24
    RULE_tipo = 25
    RULE_asignacion = 26
    RULE_asignacionSimple = 27
    RULE_opal = 28
    RULE_expOR = 29
    RULE_expORp = 30
    RULE_expAND = 31
    RULE_expANDp = 32
    RULE_expIGUAL = 33
    RULE_expIGUALp = 34
    RULE_expCOMP = 35
    RULE_expCOMPp = 36
    RULE_expSUMA = 37
    RULE_expSUMAp = 38
    RULE_term = 39
    RULE_termp = 40
    RULE_factor = 41

    ruleNames =  [ "programa", "instrucciones", "instruccion", "bloque", 
                   "autosuma", "autoresta", "auto", "iwhile", "ifor", "iif", 
                   "ielse", "declaracion", "listavar", "inic", "ireturn", 
                   "parametro", "prototipoFunc", "parametros", "listapar", 
                   "argumento", "argumentos", "listaargumentos", "llamadaFunc", 
                   "llamadaFuncInstruccion", "declaracionFunc", "tipo", 
                   "asignacion", "asignacionSimple", "opal", "expOR", "expORp", 
                   "expAND", "expANDp", "expIGUAL", "expIGUALp", "expCOMP", 
                   "expCOMPp", "expSUMA", "expSUMAp", "term", "termp", "factor" ]

    EOF = Token.EOF
    PA=1
    PC=2
    LLA=3
    LLC=4
    PYC=5
    ASIG=6
    NUMERO=7
    INT=8
    DOUBLE=9
    VOID=10
    WHILE=11
    IF=12
    ELSE=13
    FOR=14
    COMA=15
    SUMA=16
    ASUMA=17
    RESTA=18
    ARESTA=19
    MULT=20
    DIV=21
    MOD=22
    MA=23
    ME=24
    MAI=25
    MEI=26
    AND=27
    OR=28
    IGUALDAD=29
    DESIGUALDAD=30
    RETURN=31
    ID=32
    WS=33
    OTRO=34

    def __init__(self, input:TokenStream, output:TextIO = sys.stdout):
        super().__init__(input, output)
        self.checkVersion("4.13.1")
        self._interp = ParserATNSimulator(self, self.atn, self.decisionsToDFA, self.sharedContextCache)
        self._predicates = None




    class ProgramaContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def instrucciones(self):
            return self.getTypedRuleContext(compiladorParser.InstruccionesContext,0)


        def EOF(self):
            return self.getToken(compiladorParser.EOF, 0)

        def getRuleIndex(self):
            return compiladorParser.RULE_programa

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterPrograma" ):
                listener.enterPrograma(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitPrograma" ):
                listener.exitPrograma(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitPrograma" ):
                return visitor.visitPrograma(self)
            else:
                return visitor.visitChildren(self)




    def programa(self):

        localctx = compiladorParser.ProgramaContext(self, self._ctx, self.state)
        self.enterRule(localctx, 0, self.RULE_programa)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 84
            self.instrucciones()
            self.state = 85
            self.match(compiladorParser.EOF)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class InstruccionesContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def instruccion(self):
            return self.getTypedRuleContext(compiladorParser.InstruccionContext,0)


        def instrucciones(self):
            return self.getTypedRuleContext(compiladorParser.InstruccionesContext,0)


        def getRuleIndex(self):
            return compiladorParser.RULE_instrucciones

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterInstrucciones" ):
                listener.enterInstrucciones(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitInstrucciones" ):
                listener.exitInstrucciones(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitInstrucciones" ):
                return visitor.visitInstrucciones(self)
            else:
                return visitor.visitChildren(self)




    def instrucciones(self):

        localctx = compiladorParser.InstruccionesContext(self, self._ctx, self.state)
        self.enterRule(localctx, 2, self.RULE_instrucciones)
        try:
            self.state = 91
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [3, 8, 9, 10, 11, 12, 14, 17, 19, 31, 32]:
                self.enterOuterAlt(localctx, 1)
                self.state = 87
                self.instruccion()
                self.state = 88
                self.instrucciones()
                pass
            elif token in [-1, 4]:
                self.enterOuterAlt(localctx, 2)

                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class InstruccionContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def auto(self):
            return self.getTypedRuleContext(compiladorParser.AutoContext,0)


        def asignacion(self):
            return self.getTypedRuleContext(compiladorParser.AsignacionContext,0)


        def declaracion(self):
            return self.getTypedRuleContext(compiladorParser.DeclaracionContext,0)


        def prototipoFunc(self):
            return self.getTypedRuleContext(compiladorParser.PrototipoFuncContext,0)


        def llamadaFuncInstruccion(self):
            return self.getTypedRuleContext(compiladorParser.LlamadaFuncInstruccionContext,0)


        def declaracionFunc(self):
            return self.getTypedRuleContext(compiladorParser.DeclaracionFuncContext,0)


        def iwhile(self):
            return self.getTypedRuleContext(compiladorParser.IwhileContext,0)


        def iif(self):
            return self.getTypedRuleContext(compiladorParser.IifContext,0)


        def ifor(self):
            return self.getTypedRuleContext(compiladorParser.IforContext,0)


        def ireturn(self):
            return self.getTypedRuleContext(compiladorParser.IreturnContext,0)


        def bloque(self):
            return self.getTypedRuleContext(compiladorParser.BloqueContext,0)


        def getRuleIndex(self):
            return compiladorParser.RULE_instruccion

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterInstruccion" ):
                listener.enterInstruccion(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitInstruccion" ):
                listener.exitInstruccion(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitInstruccion" ):
                return visitor.visitInstruccion(self)
            else:
                return visitor.visitChildren(self)




    def instruccion(self):

        localctx = compiladorParser.InstruccionContext(self, self._ctx, self.state)
        self.enterRule(localctx, 4, self.RULE_instruccion)
        try:
            self.state = 104
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,1,self._ctx)
            if la_ == 1:
                self.enterOuterAlt(localctx, 1)
                self.state = 93
                self.auto()
                pass

            elif la_ == 2:
                self.enterOuterAlt(localctx, 2)
                self.state = 94
                self.asignacion()
                pass

            elif la_ == 3:
                self.enterOuterAlt(localctx, 3)
                self.state = 95
                self.declaracion()
                pass

            elif la_ == 4:
                self.enterOuterAlt(localctx, 4)
                self.state = 96
                self.prototipoFunc()
                pass

            elif la_ == 5:
                self.enterOuterAlt(localctx, 5)
                self.state = 97
                self.llamadaFuncInstruccion()
                pass

            elif la_ == 6:
                self.enterOuterAlt(localctx, 6)
                self.state = 98
                self.declaracionFunc()
                pass

            elif la_ == 7:
                self.enterOuterAlt(localctx, 7)
                self.state = 99
                self.iwhile()
                pass

            elif la_ == 8:
                self.enterOuterAlt(localctx, 8)
                self.state = 100
                self.iif()
                pass

            elif la_ == 9:
                self.enterOuterAlt(localctx, 9)
                self.state = 101
                self.ifor()
                pass

            elif la_ == 10:
                self.enterOuterAlt(localctx, 10)
                self.state = 102
                self.ireturn()
                pass

            elif la_ == 11:
                self.enterOuterAlt(localctx, 11)
                self.state = 103
                self.bloque()
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class BloqueContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def LLA(self):
            return self.getToken(compiladorParser.LLA, 0)

        def instrucciones(self):
            return self.getTypedRuleContext(compiladorParser.InstruccionesContext,0)


        def LLC(self):
            return self.getToken(compiladorParser.LLC, 0)

        def getRuleIndex(self):
            return compiladorParser.RULE_bloque

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterBloque" ):
                listener.enterBloque(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitBloque" ):
                listener.exitBloque(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitBloque" ):
                return visitor.visitBloque(self)
            else:
                return visitor.visitChildren(self)




    def bloque(self):

        localctx = compiladorParser.BloqueContext(self, self._ctx, self.state)
        self.enterRule(localctx, 6, self.RULE_bloque)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 106
            self.match(compiladorParser.LLA)
            self.state = 107
            self.instrucciones()
            self.state = 108
            self.match(compiladorParser.LLC)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class AutosumaContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ID(self):
            return self.getToken(compiladorParser.ID, 0)

        def ASUMA(self):
            return self.getToken(compiladorParser.ASUMA, 0)

        def getRuleIndex(self):
            return compiladorParser.RULE_autosuma

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterAutosuma" ):
                listener.enterAutosuma(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitAutosuma" ):
                listener.exitAutosuma(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitAutosuma" ):
                return visitor.visitAutosuma(self)
            else:
                return visitor.visitChildren(self)




    def autosuma(self):

        localctx = compiladorParser.AutosumaContext(self, self._ctx, self.state)
        self.enterRule(localctx, 8, self.RULE_autosuma)
        try:
            self.state = 114
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [32]:
                self.enterOuterAlt(localctx, 1)
                self.state = 110
                self.match(compiladorParser.ID)
                self.state = 111
                self.match(compiladorParser.ASUMA)
                pass
            elif token in [17]:
                self.enterOuterAlt(localctx, 2)
                self.state = 112
                self.match(compiladorParser.ASUMA)
                self.state = 113
                self.match(compiladorParser.ID)
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class AutorestaContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ID(self):
            return self.getToken(compiladorParser.ID, 0)

        def ARESTA(self):
            return self.getToken(compiladorParser.ARESTA, 0)

        def getRuleIndex(self):
            return compiladorParser.RULE_autoresta

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterAutoresta" ):
                listener.enterAutoresta(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitAutoresta" ):
                listener.exitAutoresta(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitAutoresta" ):
                return visitor.visitAutoresta(self)
            else:
                return visitor.visitChildren(self)




    def autoresta(self):

        localctx = compiladorParser.AutorestaContext(self, self._ctx, self.state)
        self.enterRule(localctx, 10, self.RULE_autoresta)
        try:
            self.state = 120
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [32]:
                self.enterOuterAlt(localctx, 1)
                self.state = 116
                self.match(compiladorParser.ID)
                self.state = 117
                self.match(compiladorParser.ARESTA)
                pass
            elif token in [19]:
                self.enterOuterAlt(localctx, 2)
                self.state = 118
                self.match(compiladorParser.ARESTA)
                self.state = 119
                self.match(compiladorParser.ID)
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class AutoContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def autosuma(self):
            return self.getTypedRuleContext(compiladorParser.AutosumaContext,0)


        def autoresta(self):
            return self.getTypedRuleContext(compiladorParser.AutorestaContext,0)


        def getRuleIndex(self):
            return compiladorParser.RULE_auto

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterAuto" ):
                listener.enterAuto(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitAuto" ):
                listener.exitAuto(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitAuto" ):
                return visitor.visitAuto(self)
            else:
                return visitor.visitChildren(self)




    def auto(self):

        localctx = compiladorParser.AutoContext(self, self._ctx, self.state)
        self.enterRule(localctx, 12, self.RULE_auto)
        try:
            self.state = 124
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,4,self._ctx)
            if la_ == 1:
                self.enterOuterAlt(localctx, 1)
                self.state = 122
                self.autosuma()
                pass

            elif la_ == 2:
                self.enterOuterAlt(localctx, 2)
                self.state = 123
                self.autoresta()
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class IwhileContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def WHILE(self):
            return self.getToken(compiladorParser.WHILE, 0)

        def PA(self):
            return self.getToken(compiladorParser.PA, 0)

        def opal(self):
            return self.getTypedRuleContext(compiladorParser.OpalContext,0)


        def PC(self):
            return self.getToken(compiladorParser.PC, 0)

        def instruccion(self):
            return self.getTypedRuleContext(compiladorParser.InstruccionContext,0)


        def getRuleIndex(self):
            return compiladorParser.RULE_iwhile

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterIwhile" ):
                listener.enterIwhile(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitIwhile" ):
                listener.exitIwhile(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitIwhile" ):
                return visitor.visitIwhile(self)
            else:
                return visitor.visitChildren(self)




    def iwhile(self):

        localctx = compiladorParser.IwhileContext(self, self._ctx, self.state)
        self.enterRule(localctx, 14, self.RULE_iwhile)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 126
            self.match(compiladorParser.WHILE)
            self.state = 127
            self.match(compiladorParser.PA)
            self.state = 128
            self.opal()
            self.state = 129
            self.match(compiladorParser.PC)
            self.state = 130
            self.instruccion()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class IforContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def FOR(self):
            return self.getToken(compiladorParser.FOR, 0)

        def PA(self):
            return self.getToken(compiladorParser.PA, 0)

        def tipo(self):
            return self.getTypedRuleContext(compiladorParser.TipoContext,0)


        def asignacionSimple(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(compiladorParser.AsignacionSimpleContext)
            else:
                return self.getTypedRuleContext(compiladorParser.AsignacionSimpleContext,i)


        def PYC(self, i:int=None):
            if i is None:
                return self.getTokens(compiladorParser.PYC)
            else:
                return self.getToken(compiladorParser.PYC, i)

        def opal(self):
            return self.getTypedRuleContext(compiladorParser.OpalContext,0)


        def auto(self):
            return self.getTypedRuleContext(compiladorParser.AutoContext,0)


        def PC(self):
            return self.getToken(compiladorParser.PC, 0)

        def instruccion(self):
            return self.getTypedRuleContext(compiladorParser.InstruccionContext,0)


        def asignacion(self):
            return self.getTypedRuleContext(compiladorParser.AsignacionContext,0)


        def getRuleIndex(self):
            return compiladorParser.RULE_ifor

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterIfor" ):
                listener.enterIfor(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitIfor" ):
                listener.exitIfor(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitIfor" ):
                return visitor.visitIfor(self)
            else:
                return visitor.visitChildren(self)




    def ifor(self):

        localctx = compiladorParser.IforContext(self, self._ctx, self.state)
        self.enterRule(localctx, 16, self.RULE_ifor)
        try:
            self.state = 172
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,5,self._ctx)
            if la_ == 1:
                self.enterOuterAlt(localctx, 1)
                self.state = 132
                self.match(compiladorParser.FOR)
                self.state = 133
                self.match(compiladorParser.PA)
                self.state = 134
                self.tipo()
                self.state = 135
                self.asignacionSimple()
                self.state = 136
                self.match(compiladorParser.PYC)
                self.state = 137
                self.opal()
                self.state = 138
                self.match(compiladorParser.PYC)
                self.state = 139
                self.auto()
                self.state = 140
                self.match(compiladorParser.PC)
                self.state = 141
                self.instruccion()
                pass

            elif la_ == 2:
                self.enterOuterAlt(localctx, 2)
                self.state = 143
                self.match(compiladorParser.FOR)
                self.state = 144
                self.match(compiladorParser.PA)
                self.state = 145
                self.tipo()
                self.state = 146
                self.asignacionSimple()
                self.state = 147
                self.match(compiladorParser.PYC)
                self.state = 148
                self.opal()
                self.state = 149
                self.match(compiladorParser.PYC)
                self.state = 150
                self.asignacionSimple()
                self.state = 151
                self.match(compiladorParser.PC)
                self.state = 152
                self.instruccion()
                pass

            elif la_ == 3:
                self.enterOuterAlt(localctx, 3)
                self.state = 154
                self.match(compiladorParser.FOR)
                self.state = 155
                self.match(compiladorParser.PA)
                self.state = 156
                self.asignacion()
                self.state = 157
                self.opal()
                self.state = 158
                self.match(compiladorParser.PYC)
                self.state = 159
                self.auto()
                self.state = 160
                self.match(compiladorParser.PC)
                self.state = 161
                self.instruccion()
                pass

            elif la_ == 4:
                self.enterOuterAlt(localctx, 4)
                self.state = 163
                self.match(compiladorParser.FOR)
                self.state = 164
                self.match(compiladorParser.PA)
                self.state = 165
                self.asignacion()
                self.state = 166
                self.opal()
                self.state = 167
                self.match(compiladorParser.PYC)
                self.state = 168
                self.asignacionSimple()
                self.state = 169
                self.match(compiladorParser.PC)
                self.state = 170
                self.instruccion()
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class IifContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def IF(self):
            return self.getToken(compiladorParser.IF, 0)

        def PA(self):
            return self.getToken(compiladorParser.PA, 0)

        def opal(self):
            return self.getTypedRuleContext(compiladorParser.OpalContext,0)


        def PC(self):
            return self.getToken(compiladorParser.PC, 0)

        def instruccion(self):
            return self.getTypedRuleContext(compiladorParser.InstruccionContext,0)


        def ielse(self):
            return self.getTypedRuleContext(compiladorParser.IelseContext,0)


        def getRuleIndex(self):
            return compiladorParser.RULE_iif

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterIif" ):
                listener.enterIif(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitIif" ):
                listener.exitIif(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitIif" ):
                return visitor.visitIif(self)
            else:
                return visitor.visitChildren(self)




    def iif(self):

        localctx = compiladorParser.IifContext(self, self._ctx, self.state)
        self.enterRule(localctx, 18, self.RULE_iif)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 174
            self.match(compiladorParser.IF)
            self.state = 175
            self.match(compiladorParser.PA)
            self.state = 176
            self.opal()
            self.state = 177
            self.match(compiladorParser.PC)
            self.state = 178
            self.instruccion()
            self.state = 179
            self.ielse()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class IelseContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ELSE(self):
            return self.getToken(compiladorParser.ELSE, 0)

        def instruccion(self):
            return self.getTypedRuleContext(compiladorParser.InstruccionContext,0)


        def getRuleIndex(self):
            return compiladorParser.RULE_ielse

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterIelse" ):
                listener.enterIelse(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitIelse" ):
                listener.exitIelse(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitIelse" ):
                return visitor.visitIelse(self)
            else:
                return visitor.visitChildren(self)




    def ielse(self):

        localctx = compiladorParser.IelseContext(self, self._ctx, self.state)
        self.enterRule(localctx, 20, self.RULE_ielse)
        try:
            self.state = 184
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,6,self._ctx)
            if la_ == 1:
                self.enterOuterAlt(localctx, 1)
                self.state = 181
                self.match(compiladorParser.ELSE)
                self.state = 182
                self.instruccion()
                pass

            elif la_ == 2:
                self.enterOuterAlt(localctx, 2)

                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class DeclaracionContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def tipo(self):
            return self.getTypedRuleContext(compiladorParser.TipoContext,0)


        def ID(self):
            return self.getToken(compiladorParser.ID, 0)

        def inic(self):
            return self.getTypedRuleContext(compiladorParser.InicContext,0)


        def listavar(self):
            return self.getTypedRuleContext(compiladorParser.ListavarContext,0)


        def PYC(self):
            return self.getToken(compiladorParser.PYC, 0)

        def getRuleIndex(self):
            return compiladorParser.RULE_declaracion

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterDeclaracion" ):
                listener.enterDeclaracion(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitDeclaracion" ):
                listener.exitDeclaracion(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitDeclaracion" ):
                return visitor.visitDeclaracion(self)
            else:
                return visitor.visitChildren(self)




    def declaracion(self):

        localctx = compiladorParser.DeclaracionContext(self, self._ctx, self.state)
        self.enterRule(localctx, 22, self.RULE_declaracion)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 186
            self.tipo()
            self.state = 187
            self.match(compiladorParser.ID)
            self.state = 188
            self.inic()
            self.state = 189
            self.listavar()
            self.state = 190
            self.match(compiladorParser.PYC)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ListavarContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def COMA(self):
            return self.getToken(compiladorParser.COMA, 0)

        def ID(self):
            return self.getToken(compiladorParser.ID, 0)

        def inic(self):
            return self.getTypedRuleContext(compiladorParser.InicContext,0)


        def listavar(self):
            return self.getTypedRuleContext(compiladorParser.ListavarContext,0)


        def getRuleIndex(self):
            return compiladorParser.RULE_listavar

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterListavar" ):
                listener.enterListavar(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitListavar" ):
                listener.exitListavar(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitListavar" ):
                return visitor.visitListavar(self)
            else:
                return visitor.visitChildren(self)




    def listavar(self):

        localctx = compiladorParser.ListavarContext(self, self._ctx, self.state)
        self.enterRule(localctx, 24, self.RULE_listavar)
        try:
            self.state = 198
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [15]:
                self.enterOuterAlt(localctx, 1)
                self.state = 192
                self.match(compiladorParser.COMA)
                self.state = 193
                self.match(compiladorParser.ID)
                self.state = 194
                self.inic()
                self.state = 195
                self.listavar()
                pass
            elif token in [5]:
                self.enterOuterAlt(localctx, 2)

                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class InicContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ASIG(self):
            return self.getToken(compiladorParser.ASIG, 0)

        def opal(self):
            return self.getTypedRuleContext(compiladorParser.OpalContext,0)


        def getRuleIndex(self):
            return compiladorParser.RULE_inic

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterInic" ):
                listener.enterInic(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitInic" ):
                listener.exitInic(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitInic" ):
                return visitor.visitInic(self)
            else:
                return visitor.visitChildren(self)




    def inic(self):

        localctx = compiladorParser.InicContext(self, self._ctx, self.state)
        self.enterRule(localctx, 26, self.RULE_inic)
        try:
            self.state = 203
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [6]:
                self.enterOuterAlt(localctx, 1)
                self.state = 200
                self.match(compiladorParser.ASIG)
                self.state = 201
                self.opal()
                pass
            elif token in [5, 15]:
                self.enterOuterAlt(localctx, 2)

                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class IreturnContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def RETURN(self):
            return self.getToken(compiladorParser.RETURN, 0)

        def opal(self):
            return self.getTypedRuleContext(compiladorParser.OpalContext,0)


        def PYC(self):
            return self.getToken(compiladorParser.PYC, 0)

        def getRuleIndex(self):
            return compiladorParser.RULE_ireturn

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterIreturn" ):
                listener.enterIreturn(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitIreturn" ):
                listener.exitIreturn(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitIreturn" ):
                return visitor.visitIreturn(self)
            else:
                return visitor.visitChildren(self)




    def ireturn(self):

        localctx = compiladorParser.IreturnContext(self, self._ctx, self.state)
        self.enterRule(localctx, 28, self.RULE_ireturn)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 205
            self.match(compiladorParser.RETURN)
            self.state = 206
            self.opal()
            self.state = 207
            self.match(compiladorParser.PYC)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ParametroContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def tipo(self):
            return self.getTypedRuleContext(compiladorParser.TipoContext,0)


        def ID(self):
            return self.getToken(compiladorParser.ID, 0)

        def getRuleIndex(self):
            return compiladorParser.RULE_parametro

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterParametro" ):
                listener.enterParametro(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitParametro" ):
                listener.exitParametro(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitParametro" ):
                return visitor.visitParametro(self)
            else:
                return visitor.visitChildren(self)




    def parametro(self):

        localctx = compiladorParser.ParametroContext(self, self._ctx, self.state)
        self.enterRule(localctx, 30, self.RULE_parametro)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 209
            self.tipo()
            self.state = 210
            self.match(compiladorParser.ID)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class PrototipoFuncContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def tipo(self):
            return self.getTypedRuleContext(compiladorParser.TipoContext,0)


        def ID(self):
            return self.getToken(compiladorParser.ID, 0)

        def PA(self):
            return self.getToken(compiladorParser.PA, 0)

        def parametros(self):
            return self.getTypedRuleContext(compiladorParser.ParametrosContext,0)


        def PC(self):
            return self.getToken(compiladorParser.PC, 0)

        def PYC(self):
            return self.getToken(compiladorParser.PYC, 0)

        def getRuleIndex(self):
            return compiladorParser.RULE_prototipoFunc

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterPrototipoFunc" ):
                listener.enterPrototipoFunc(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitPrototipoFunc" ):
                listener.exitPrototipoFunc(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitPrototipoFunc" ):
                return visitor.visitPrototipoFunc(self)
            else:
                return visitor.visitChildren(self)




    def prototipoFunc(self):

        localctx = compiladorParser.PrototipoFuncContext(self, self._ctx, self.state)
        self.enterRule(localctx, 32, self.RULE_prototipoFunc)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 212
            self.tipo()
            self.state = 213
            self.match(compiladorParser.ID)
            self.state = 214
            self.match(compiladorParser.PA)
            self.state = 215
            self.parametros()
            self.state = 216
            self.match(compiladorParser.PC)
            self.state = 217
            self.match(compiladorParser.PYC)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ParametrosContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def parametro(self):
            return self.getTypedRuleContext(compiladorParser.ParametroContext,0)


        def listapar(self):
            return self.getTypedRuleContext(compiladorParser.ListaparContext,0)


        def getRuleIndex(self):
            return compiladorParser.RULE_parametros

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterParametros" ):
                listener.enterParametros(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitParametros" ):
                listener.exitParametros(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitParametros" ):
                return visitor.visitParametros(self)
            else:
                return visitor.visitChildren(self)




    def parametros(self):

        localctx = compiladorParser.ParametrosContext(self, self._ctx, self.state)
        self.enterRule(localctx, 34, self.RULE_parametros)
        try:
            self.state = 223
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [8, 9, 10]:
                self.enterOuterAlt(localctx, 1)
                self.state = 219
                self.parametro()
                self.state = 220
                self.listapar()
                pass
            elif token in [2]:
                self.enterOuterAlt(localctx, 2)

                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ListaparContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def COMA(self):
            return self.getToken(compiladorParser.COMA, 0)

        def parametro(self):
            return self.getTypedRuleContext(compiladorParser.ParametroContext,0)


        def listapar(self):
            return self.getTypedRuleContext(compiladorParser.ListaparContext,0)


        def getRuleIndex(self):
            return compiladorParser.RULE_listapar

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterListapar" ):
                listener.enterListapar(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitListapar" ):
                listener.exitListapar(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitListapar" ):
                return visitor.visitListapar(self)
            else:
                return visitor.visitChildren(self)




    def listapar(self):

        localctx = compiladorParser.ListaparContext(self, self._ctx, self.state)
        self.enterRule(localctx, 36, self.RULE_listapar)
        try:
            self.state = 230
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [15]:
                self.enterOuterAlt(localctx, 1)
                self.state = 225
                self.match(compiladorParser.COMA)
                self.state = 226
                self.parametro()
                self.state = 227
                self.listapar()
                pass
            elif token in [2]:
                self.enterOuterAlt(localctx, 2)

                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ArgumentoContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def opal(self):
            return self.getTypedRuleContext(compiladorParser.OpalContext,0)


        def getRuleIndex(self):
            return compiladorParser.RULE_argumento

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterArgumento" ):
                listener.enterArgumento(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitArgumento" ):
                listener.exitArgumento(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitArgumento" ):
                return visitor.visitArgumento(self)
            else:
                return visitor.visitChildren(self)




    def argumento(self):

        localctx = compiladorParser.ArgumentoContext(self, self._ctx, self.state)
        self.enterRule(localctx, 38, self.RULE_argumento)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 232
            self.opal()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ArgumentosContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def argumento(self):
            return self.getTypedRuleContext(compiladorParser.ArgumentoContext,0)


        def listaargumentos(self):
            return self.getTypedRuleContext(compiladorParser.ListaargumentosContext,0)


        def getRuleIndex(self):
            return compiladorParser.RULE_argumentos

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterArgumentos" ):
                listener.enterArgumentos(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitArgumentos" ):
                listener.exitArgumentos(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitArgumentos" ):
                return visitor.visitArgumentos(self)
            else:
                return visitor.visitChildren(self)




    def argumentos(self):

        localctx = compiladorParser.ArgumentosContext(self, self._ctx, self.state)
        self.enterRule(localctx, 40, self.RULE_argumentos)
        try:
            self.state = 238
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [1, 7, 32]:
                self.enterOuterAlt(localctx, 1)
                self.state = 234
                self.argumento()
                self.state = 235
                self.listaargumentos()
                pass
            elif token in [2]:
                self.enterOuterAlt(localctx, 2)

                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ListaargumentosContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def COMA(self):
            return self.getToken(compiladorParser.COMA, 0)

        def argumento(self):
            return self.getTypedRuleContext(compiladorParser.ArgumentoContext,0)


        def listaargumentos(self):
            return self.getTypedRuleContext(compiladorParser.ListaargumentosContext,0)


        def getRuleIndex(self):
            return compiladorParser.RULE_listaargumentos

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterListaargumentos" ):
                listener.enterListaargumentos(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitListaargumentos" ):
                listener.exitListaargumentos(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitListaargumentos" ):
                return visitor.visitListaargumentos(self)
            else:
                return visitor.visitChildren(self)




    def listaargumentos(self):

        localctx = compiladorParser.ListaargumentosContext(self, self._ctx, self.state)
        self.enterRule(localctx, 42, self.RULE_listaargumentos)
        try:
            self.state = 245
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [15]:
                self.enterOuterAlt(localctx, 1)
                self.state = 240
                self.match(compiladorParser.COMA)
                self.state = 241
                self.argumento()
                self.state = 242
                self.listaargumentos()
                pass
            elif token in [2]:
                self.enterOuterAlt(localctx, 2)

                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class LlamadaFuncContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ID(self):
            return self.getToken(compiladorParser.ID, 0)

        def PA(self):
            return self.getToken(compiladorParser.PA, 0)

        def argumentos(self):
            return self.getTypedRuleContext(compiladorParser.ArgumentosContext,0)


        def PC(self):
            return self.getToken(compiladorParser.PC, 0)

        def getRuleIndex(self):
            return compiladorParser.RULE_llamadaFunc

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterLlamadaFunc" ):
                listener.enterLlamadaFunc(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitLlamadaFunc" ):
                listener.exitLlamadaFunc(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitLlamadaFunc" ):
                return visitor.visitLlamadaFunc(self)
            else:
                return visitor.visitChildren(self)




    def llamadaFunc(self):

        localctx = compiladorParser.LlamadaFuncContext(self, self._ctx, self.state)
        self.enterRule(localctx, 44, self.RULE_llamadaFunc)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 247
            self.match(compiladorParser.ID)
            self.state = 248
            self.match(compiladorParser.PA)
            self.state = 249
            self.argumentos()
            self.state = 250
            self.match(compiladorParser.PC)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class LlamadaFuncInstruccionContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def llamadaFunc(self):
            return self.getTypedRuleContext(compiladorParser.LlamadaFuncContext,0)


        def PYC(self):
            return self.getToken(compiladorParser.PYC, 0)

        def getRuleIndex(self):
            return compiladorParser.RULE_llamadaFuncInstruccion

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterLlamadaFuncInstruccion" ):
                listener.enterLlamadaFuncInstruccion(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitLlamadaFuncInstruccion" ):
                listener.exitLlamadaFuncInstruccion(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitLlamadaFuncInstruccion" ):
                return visitor.visitLlamadaFuncInstruccion(self)
            else:
                return visitor.visitChildren(self)




    def llamadaFuncInstruccion(self):

        localctx = compiladorParser.LlamadaFuncInstruccionContext(self, self._ctx, self.state)
        self.enterRule(localctx, 46, self.RULE_llamadaFuncInstruccion)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 252
            self.llamadaFunc()
            self.state = 253
            self.match(compiladorParser.PYC)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class DeclaracionFuncContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def tipo(self):
            return self.getTypedRuleContext(compiladorParser.TipoContext,0)


        def ID(self):
            return self.getToken(compiladorParser.ID, 0)

        def PA(self):
            return self.getToken(compiladorParser.PA, 0)

        def parametros(self):
            return self.getTypedRuleContext(compiladorParser.ParametrosContext,0)


        def PC(self):
            return self.getToken(compiladorParser.PC, 0)

        def bloque(self):
            return self.getTypedRuleContext(compiladorParser.BloqueContext,0)


        def getRuleIndex(self):
            return compiladorParser.RULE_declaracionFunc

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterDeclaracionFunc" ):
                listener.enterDeclaracionFunc(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitDeclaracionFunc" ):
                listener.exitDeclaracionFunc(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitDeclaracionFunc" ):
                return visitor.visitDeclaracionFunc(self)
            else:
                return visitor.visitChildren(self)




    def declaracionFunc(self):

        localctx = compiladorParser.DeclaracionFuncContext(self, self._ctx, self.state)
        self.enterRule(localctx, 48, self.RULE_declaracionFunc)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 255
            self.tipo()
            self.state = 256
            self.match(compiladorParser.ID)
            self.state = 257
            self.match(compiladorParser.PA)
            self.state = 258
            self.parametros()
            self.state = 259
            self.match(compiladorParser.PC)
            self.state = 260
            self.bloque()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class TipoContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def INT(self):
            return self.getToken(compiladorParser.INT, 0)

        def DOUBLE(self):
            return self.getToken(compiladorParser.DOUBLE, 0)

        def VOID(self):
            return self.getToken(compiladorParser.VOID, 0)

        def getRuleIndex(self):
            return compiladorParser.RULE_tipo

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterTipo" ):
                listener.enterTipo(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitTipo" ):
                listener.exitTipo(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitTipo" ):
                return visitor.visitTipo(self)
            else:
                return visitor.visitChildren(self)




    def tipo(self):

        localctx = compiladorParser.TipoContext(self, self._ctx, self.state)
        self.enterRule(localctx, 50, self.RULE_tipo)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 262
            _la = self._input.LA(1)
            if not((((_la) & ~0x3f) == 0 and ((1 << _la) & 1792) != 0)):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class AsignacionContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ID(self):
            return self.getToken(compiladorParser.ID, 0)

        def ASIG(self):
            return self.getToken(compiladorParser.ASIG, 0)

        def opal(self):
            return self.getTypedRuleContext(compiladorParser.OpalContext,0)


        def PYC(self):
            return self.getToken(compiladorParser.PYC, 0)

        def getRuleIndex(self):
            return compiladorParser.RULE_asignacion

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterAsignacion" ):
                listener.enterAsignacion(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitAsignacion" ):
                listener.exitAsignacion(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitAsignacion" ):
                return visitor.visitAsignacion(self)
            else:
                return visitor.visitChildren(self)




    def asignacion(self):

        localctx = compiladorParser.AsignacionContext(self, self._ctx, self.state)
        self.enterRule(localctx, 52, self.RULE_asignacion)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 264
            self.match(compiladorParser.ID)
            self.state = 265
            self.match(compiladorParser.ASIG)
            self.state = 266
            self.opal()
            self.state = 267
            self.match(compiladorParser.PYC)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class AsignacionSimpleContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ID(self):
            return self.getToken(compiladorParser.ID, 0)

        def ASIG(self):
            return self.getToken(compiladorParser.ASIG, 0)

        def opal(self):
            return self.getTypedRuleContext(compiladorParser.OpalContext,0)


        def getRuleIndex(self):
            return compiladorParser.RULE_asignacionSimple

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterAsignacionSimple" ):
                listener.enterAsignacionSimple(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitAsignacionSimple" ):
                listener.exitAsignacionSimple(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitAsignacionSimple" ):
                return visitor.visitAsignacionSimple(self)
            else:
                return visitor.visitChildren(self)




    def asignacionSimple(self):

        localctx = compiladorParser.AsignacionSimpleContext(self, self._ctx, self.state)
        self.enterRule(localctx, 54, self.RULE_asignacionSimple)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 269
            self.match(compiladorParser.ID)
            self.state = 270
            self.match(compiladorParser.ASIG)
            self.state = 271
            self.opal()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class OpalContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def expOR(self):
            return self.getTypedRuleContext(compiladorParser.ExpORContext,0)


        def getRuleIndex(self):
            return compiladorParser.RULE_opal

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterOpal" ):
                listener.enterOpal(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitOpal" ):
                listener.exitOpal(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitOpal" ):
                return visitor.visitOpal(self)
            else:
                return visitor.visitChildren(self)




    def opal(self):

        localctx = compiladorParser.OpalContext(self, self._ctx, self.state)
        self.enterRule(localctx, 56, self.RULE_opal)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 273
            self.expOR()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ExpORContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def expAND(self):
            return self.getTypedRuleContext(compiladorParser.ExpANDContext,0)


        def expORp(self):
            return self.getTypedRuleContext(compiladorParser.ExpORpContext,0)


        def getRuleIndex(self):
            return compiladorParser.RULE_expOR

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterExpOR" ):
                listener.enterExpOR(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitExpOR" ):
                listener.exitExpOR(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitExpOR" ):
                return visitor.visitExpOR(self)
            else:
                return visitor.visitChildren(self)




    def expOR(self):

        localctx = compiladorParser.ExpORContext(self, self._ctx, self.state)
        self.enterRule(localctx, 58, self.RULE_expOR)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 275
            self.expAND()
            self.state = 276
            self.expORp()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ExpORpContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def OR(self):
            return self.getToken(compiladorParser.OR, 0)

        def expAND(self):
            return self.getTypedRuleContext(compiladorParser.ExpANDContext,0)


        def expORp(self):
            return self.getTypedRuleContext(compiladorParser.ExpORpContext,0)


        def getRuleIndex(self):
            return compiladorParser.RULE_expORp

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterExpORp" ):
                listener.enterExpORp(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitExpORp" ):
                listener.exitExpORp(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitExpORp" ):
                return visitor.visitExpORp(self)
            else:
                return visitor.visitChildren(self)




    def expORp(self):

        localctx = compiladorParser.ExpORpContext(self, self._ctx, self.state)
        self.enterRule(localctx, 60, self.RULE_expORp)
        try:
            self.state = 283
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [28]:
                self.enterOuterAlt(localctx, 1)
                self.state = 278
                self.match(compiladorParser.OR)
                self.state = 279
                self.expAND()
                self.state = 280
                self.expORp()
                pass
            elif token in [2, 5, 15]:
                self.enterOuterAlt(localctx, 2)

                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ExpANDContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def expIGUAL(self):
            return self.getTypedRuleContext(compiladorParser.ExpIGUALContext,0)


        def expANDp(self):
            return self.getTypedRuleContext(compiladorParser.ExpANDpContext,0)


        def getRuleIndex(self):
            return compiladorParser.RULE_expAND

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterExpAND" ):
                listener.enterExpAND(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitExpAND" ):
                listener.exitExpAND(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitExpAND" ):
                return visitor.visitExpAND(self)
            else:
                return visitor.visitChildren(self)




    def expAND(self):

        localctx = compiladorParser.ExpANDContext(self, self._ctx, self.state)
        self.enterRule(localctx, 62, self.RULE_expAND)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 285
            self.expIGUAL()
            self.state = 286
            self.expANDp()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ExpANDpContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def AND(self):
            return self.getToken(compiladorParser.AND, 0)

        def expIGUAL(self):
            return self.getTypedRuleContext(compiladorParser.ExpIGUALContext,0)


        def expANDp(self):
            return self.getTypedRuleContext(compiladorParser.ExpANDpContext,0)


        def getRuleIndex(self):
            return compiladorParser.RULE_expANDp

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterExpANDp" ):
                listener.enterExpANDp(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitExpANDp" ):
                listener.exitExpANDp(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitExpANDp" ):
                return visitor.visitExpANDp(self)
            else:
                return visitor.visitChildren(self)




    def expANDp(self):

        localctx = compiladorParser.ExpANDpContext(self, self._ctx, self.state)
        self.enterRule(localctx, 64, self.RULE_expANDp)
        try:
            self.state = 293
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [27]:
                self.enterOuterAlt(localctx, 1)
                self.state = 288
                self.match(compiladorParser.AND)
                self.state = 289
                self.expIGUAL()
                self.state = 290
                self.expANDp()
                pass
            elif token in [2, 5, 15, 28]:
                self.enterOuterAlt(localctx, 2)

                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ExpIGUALContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def expCOMP(self):
            return self.getTypedRuleContext(compiladorParser.ExpCOMPContext,0)


        def expIGUALp(self):
            return self.getTypedRuleContext(compiladorParser.ExpIGUALpContext,0)


        def getRuleIndex(self):
            return compiladorParser.RULE_expIGUAL

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterExpIGUAL" ):
                listener.enterExpIGUAL(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitExpIGUAL" ):
                listener.exitExpIGUAL(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitExpIGUAL" ):
                return visitor.visitExpIGUAL(self)
            else:
                return visitor.visitChildren(self)




    def expIGUAL(self):

        localctx = compiladorParser.ExpIGUALContext(self, self._ctx, self.state)
        self.enterRule(localctx, 66, self.RULE_expIGUAL)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 295
            self.expCOMP()
            self.state = 296
            self.expIGUALp()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ExpIGUALpContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def IGUALDAD(self):
            return self.getToken(compiladorParser.IGUALDAD, 0)

        def expCOMP(self):
            return self.getTypedRuleContext(compiladorParser.ExpCOMPContext,0)


        def expIGUALp(self):
            return self.getTypedRuleContext(compiladorParser.ExpIGUALpContext,0)


        def DESIGUALDAD(self):
            return self.getToken(compiladorParser.DESIGUALDAD, 0)

        def getRuleIndex(self):
            return compiladorParser.RULE_expIGUALp

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterExpIGUALp" ):
                listener.enterExpIGUALp(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitExpIGUALp" ):
                listener.exitExpIGUALp(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitExpIGUALp" ):
                return visitor.visitExpIGUALp(self)
            else:
                return visitor.visitChildren(self)




    def expIGUALp(self):

        localctx = compiladorParser.ExpIGUALpContext(self, self._ctx, self.state)
        self.enterRule(localctx, 68, self.RULE_expIGUALp)
        try:
            self.state = 307
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [29]:
                self.enterOuterAlt(localctx, 1)
                self.state = 298
                self.match(compiladorParser.IGUALDAD)
                self.state = 299
                self.expCOMP()
                self.state = 300
                self.expIGUALp()
                pass
            elif token in [30]:
                self.enterOuterAlt(localctx, 2)
                self.state = 302
                self.match(compiladorParser.DESIGUALDAD)
                self.state = 303
                self.expCOMP()
                self.state = 304
                self.expIGUALp()
                pass
            elif token in [2, 5, 15, 27, 28]:
                self.enterOuterAlt(localctx, 3)

                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ExpCOMPContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def expSUMA(self):
            return self.getTypedRuleContext(compiladorParser.ExpSUMAContext,0)


        def expCOMPp(self):
            return self.getTypedRuleContext(compiladorParser.ExpCOMPpContext,0)


        def getRuleIndex(self):
            return compiladorParser.RULE_expCOMP

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterExpCOMP" ):
                listener.enterExpCOMP(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitExpCOMP" ):
                listener.exitExpCOMP(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitExpCOMP" ):
                return visitor.visitExpCOMP(self)
            else:
                return visitor.visitChildren(self)




    def expCOMP(self):

        localctx = compiladorParser.ExpCOMPContext(self, self._ctx, self.state)
        self.enterRule(localctx, 70, self.RULE_expCOMP)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 309
            self.expSUMA()
            self.state = 310
            self.expCOMPp()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ExpCOMPpContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def MA(self):
            return self.getToken(compiladorParser.MA, 0)

        def expSUMA(self):
            return self.getTypedRuleContext(compiladorParser.ExpSUMAContext,0)


        def expCOMPp(self):
            return self.getTypedRuleContext(compiladorParser.ExpCOMPpContext,0)


        def ME(self):
            return self.getToken(compiladorParser.ME, 0)

        def MAI(self):
            return self.getToken(compiladorParser.MAI, 0)

        def MEI(self):
            return self.getToken(compiladorParser.MEI, 0)

        def getRuleIndex(self):
            return compiladorParser.RULE_expCOMPp

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterExpCOMPp" ):
                listener.enterExpCOMPp(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitExpCOMPp" ):
                listener.exitExpCOMPp(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitExpCOMPp" ):
                return visitor.visitExpCOMPp(self)
            else:
                return visitor.visitChildren(self)




    def expCOMPp(self):

        localctx = compiladorParser.ExpCOMPpContext(self, self._ctx, self.state)
        self.enterRule(localctx, 72, self.RULE_expCOMPp)
        try:
            self.state = 329
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [23]:
                self.enterOuterAlt(localctx, 1)
                self.state = 312
                self.match(compiladorParser.MA)
                self.state = 313
                self.expSUMA()
                self.state = 314
                self.expCOMPp()
                pass
            elif token in [24]:
                self.enterOuterAlt(localctx, 2)
                self.state = 316
                self.match(compiladorParser.ME)
                self.state = 317
                self.expSUMA()
                self.state = 318
                self.expCOMPp()
                pass
            elif token in [25]:
                self.enterOuterAlt(localctx, 3)
                self.state = 320
                self.match(compiladorParser.MAI)
                self.state = 321
                self.expSUMA()
                self.state = 322
                self.expCOMPp()
                pass
            elif token in [26]:
                self.enterOuterAlt(localctx, 4)
                self.state = 324
                self.match(compiladorParser.MEI)
                self.state = 325
                self.expSUMA()
                self.state = 326
                self.expCOMPp()
                pass
            elif token in [2, 5, 15, 27, 28, 29, 30]:
                self.enterOuterAlt(localctx, 5)

                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ExpSUMAContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def term(self):
            return self.getTypedRuleContext(compiladorParser.TermContext,0)


        def expSUMAp(self):
            return self.getTypedRuleContext(compiladorParser.ExpSUMApContext,0)


        def getRuleIndex(self):
            return compiladorParser.RULE_expSUMA

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterExpSUMA" ):
                listener.enterExpSUMA(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitExpSUMA" ):
                listener.exitExpSUMA(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitExpSUMA" ):
                return visitor.visitExpSUMA(self)
            else:
                return visitor.visitChildren(self)




    def expSUMA(self):

        localctx = compiladorParser.ExpSUMAContext(self, self._ctx, self.state)
        self.enterRule(localctx, 74, self.RULE_expSUMA)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 331
            self.term()
            self.state = 332
            self.expSUMAp()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ExpSUMApContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def SUMA(self):
            return self.getToken(compiladorParser.SUMA, 0)

        def term(self):
            return self.getTypedRuleContext(compiladorParser.TermContext,0)


        def expSUMAp(self):
            return self.getTypedRuleContext(compiladorParser.ExpSUMApContext,0)


        def RESTA(self):
            return self.getToken(compiladorParser.RESTA, 0)

        def getRuleIndex(self):
            return compiladorParser.RULE_expSUMAp

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterExpSUMAp" ):
                listener.enterExpSUMAp(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitExpSUMAp" ):
                listener.exitExpSUMAp(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitExpSUMAp" ):
                return visitor.visitExpSUMAp(self)
            else:
                return visitor.visitChildren(self)




    def expSUMAp(self):

        localctx = compiladorParser.ExpSUMApContext(self, self._ctx, self.state)
        self.enterRule(localctx, 76, self.RULE_expSUMAp)
        try:
            self.state = 343
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [16]:
                self.enterOuterAlt(localctx, 1)
                self.state = 334
                self.match(compiladorParser.SUMA)
                self.state = 335
                self.term()
                self.state = 336
                self.expSUMAp()
                pass
            elif token in [18]:
                self.enterOuterAlt(localctx, 2)
                self.state = 338
                self.match(compiladorParser.RESTA)
                self.state = 339
                self.term()
                self.state = 340
                self.expSUMAp()
                pass
            elif token in [2, 5, 15, 23, 24, 25, 26, 27, 28, 29, 30]:
                self.enterOuterAlt(localctx, 3)

                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class TermContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def factor(self):
            return self.getTypedRuleContext(compiladorParser.FactorContext,0)


        def termp(self):
            return self.getTypedRuleContext(compiladorParser.TermpContext,0)


        def getRuleIndex(self):
            return compiladorParser.RULE_term

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterTerm" ):
                listener.enterTerm(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitTerm" ):
                listener.exitTerm(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitTerm" ):
                return visitor.visitTerm(self)
            else:
                return visitor.visitChildren(self)




    def term(self):

        localctx = compiladorParser.TermContext(self, self._ctx, self.state)
        self.enterRule(localctx, 78, self.RULE_term)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 345
            self.factor()
            self.state = 346
            self.termp()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class TermpContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def MULT(self):
            return self.getToken(compiladorParser.MULT, 0)

        def factor(self):
            return self.getTypedRuleContext(compiladorParser.FactorContext,0)


        def termp(self):
            return self.getTypedRuleContext(compiladorParser.TermpContext,0)


        def DIV(self):
            return self.getToken(compiladorParser.DIV, 0)

        def MOD(self):
            return self.getToken(compiladorParser.MOD, 0)

        def getRuleIndex(self):
            return compiladorParser.RULE_termp

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterTermp" ):
                listener.enterTermp(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitTermp" ):
                listener.exitTermp(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitTermp" ):
                return visitor.visitTermp(self)
            else:
                return visitor.visitChildren(self)




    def termp(self):

        localctx = compiladorParser.TermpContext(self, self._ctx, self.state)
        self.enterRule(localctx, 80, self.RULE_termp)
        try:
            self.state = 361
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [20]:
                self.enterOuterAlt(localctx, 1)
                self.state = 348
                self.match(compiladorParser.MULT)
                self.state = 349
                self.factor()
                self.state = 350
                self.termp()
                pass
            elif token in [21]:
                self.enterOuterAlt(localctx, 2)
                self.state = 352
                self.match(compiladorParser.DIV)
                self.state = 353
                self.factor()
                self.state = 354
                self.termp()
                pass
            elif token in [22]:
                self.enterOuterAlt(localctx, 3)
                self.state = 356
                self.match(compiladorParser.MOD)
                self.state = 357
                self.factor()
                self.state = 358
                self.termp()
                pass
            elif token in [2, 5, 15, 16, 18, 23, 24, 25, 26, 27, 28, 29, 30]:
                self.enterOuterAlt(localctx, 4)

                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class FactorContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def NUMERO(self):
            return self.getToken(compiladorParser.NUMERO, 0)

        def ID(self):
            return self.getToken(compiladorParser.ID, 0)

        def llamadaFunc(self):
            return self.getTypedRuleContext(compiladorParser.LlamadaFuncContext,0)


        def PA(self):
            return self.getToken(compiladorParser.PA, 0)

        def opal(self):
            return self.getTypedRuleContext(compiladorParser.OpalContext,0)


        def PC(self):
            return self.getToken(compiladorParser.PC, 0)

        def getRuleIndex(self):
            return compiladorParser.RULE_factor

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterFactor" ):
                listener.enterFactor(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitFactor" ):
                listener.exitFactor(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitFactor" ):
                return visitor.visitFactor(self)
            else:
                return visitor.visitChildren(self)




    def factor(self):

        localctx = compiladorParser.FactorContext(self, self._ctx, self.state)
        self.enterRule(localctx, 82, self.RULE_factor)
        try:
            self.state = 370
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,19,self._ctx)
            if la_ == 1:
                self.enterOuterAlt(localctx, 1)
                self.state = 363
                self.match(compiladorParser.NUMERO)
                pass

            elif la_ == 2:
                self.enterOuterAlt(localctx, 2)
                self.state = 364
                self.match(compiladorParser.ID)
                pass

            elif la_ == 3:
                self.enterOuterAlt(localctx, 3)
                self.state = 365
                self.llamadaFunc()
                pass

            elif la_ == 4:
                self.enterOuterAlt(localctx, 4)
                self.state = 366
                self.match(compiladorParser.PA)
                self.state = 367
                self.opal()
                self.state = 368
                self.match(compiladorParser.PC)
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx





